"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Check, Copy } from "lucide-react"
import { cn } from "@/lib/utils"

interface ComponentPreviewProps {
  name: string
  description?: string
  preview: React.ReactNode
  code: string
  className?: string
}

export const ComponentPreview = ({
  name,
  description,
  preview,
  code,
  className,
}: ComponentPreviewProps) => {
  const [copied, setCopied] = useState(false)

  const handleCopy = async () => {
    await navigator.clipboard.writeText(code)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className={cn("rounded-lg border border-border/50 bg-surface-secondary overflow-hidden", className)}>
      {/* Header */}
      <div className="border-b border-border/50 bg-muted/30 px-6 py-4">
        <h3 className="text-lg font-semibold text-foreground">{name}</h3>
        {description && (
          <p className="text-sm text-muted-foreground mt-1">{description}</p>
        )}
      </div>

      {/* Tabs */}
      <Tabs defaultValue="preview" className="w-full">
        <div className="border-b border-border/50 bg-muted/20 px-6">
          <TabsList className="h-12 bg-transparent border-0 p-0 gap-4">
            <TabsTrigger
              value="preview"
              className="relative rounded-none border-0 bg-transparent px-0 pb-3 pt-0 font-medium text-muted-foreground shadow-none transition-none data-[state=active]:text-foreground data-[state=active]:shadow-none after:absolute after:inset-x-0 after:bottom-0 after:h-0.5 data-[state=active]:after:bg-primary"
            >
              Preview
            </TabsTrigger>
            <TabsTrigger
              value="code"
              className="relative rounded-none border-0 bg-transparent px-0 pb-3 pt-0 font-medium text-muted-foreground shadow-none transition-none data-[state=active]:text-foreground data-[state=active]:shadow-none after:absolute after:inset-x-0 after:bottom-0 after:h-0.5 data-[state=active]:after:bg-primary"
            >
              Code
            </TabsTrigger>
          </TabsList>
        </div>

        {/* Preview Tab */}
        <TabsContent value="preview" className="mt-0 p-8 bg-background min-h-[300px] flex items-center justify-center">
          <div className="w-full max-w-3xl">
            {preview}
          </div>
        </TabsContent>

        {/* Code Tab */}
        <TabsContent value="code" className="mt-0 relative">
          <div className="absolute top-4 right-4 z-10">
            <Button
              size="sm"
              variant="outline"
              onClick={handleCopy}
              className="h-8 gap-2 bg-background/95 backdrop-blur-sm hover:bg-background"
            >
              {copied ? (
                <>
                  <Check className="h-3 w-3" />
                  <span className="text-xs">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="h-3 w-3" />
                  <span className="text-xs">Copy</span>
                </>
              )}
            </Button>
          </div>
          <pre className="bg-muted/50 p-6 overflow-x-auto rounded-none">
            <code className="text-sm font-mono text-foreground leading-relaxed">
              {code}
            </code>
          </pre>
        </TabsContent>
      </Tabs>
    </div>
  )
}

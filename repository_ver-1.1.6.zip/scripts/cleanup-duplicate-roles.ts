import { db } from '@/lib/db'

/**
 * Cleanup script to remove duplicate system roles
 * Issue: Old roles have NULL agencyId/subAccountId, new ones use empty strings
 * This script removes the old NULL-valued duplicates
 */

async function main() {
  console.log('🧹 Cleaning up duplicate system roles...\n')

  const systemRoleNames = [
    'AGENCY_OWNER',
    'AGENCY_ADMIN',
    'AGENCY_USER',
    'SUBACCOUNT_ADMIN',
    'SUBACCOUNT_USER',
    'SUBACCOUNT_GUEST',
  ]

  for (const roleName of systemRoleNames) {
    // Find all roles with this name
    const roles = await db.role.findMany({
      where: { name: roleName, isSystem: true },
      orderBy: { createdAt: 'asc' },
    })

    if (roles.length > 1) {
      console.log(`⚠️  Found ${roles.length} roles named "${roleName}":`)
      
      // Keep the newest one (with empty strings)
      const toKeep = roles[roles.length - 1]
      const toDelete = roles.slice(0, -1)

      console.log(`   ✓ Keeping: ${toKeep.id} (created ${toKeep.createdAt})`)
      
      for (const role of toDelete) {
        console.log(`   🗑️  Deleting: ${role.id} (created ${role.createdAt})`)
        
        // First, reassign agency memberships to the new role
        const agencyMembershipCount = await db.agencyMembership.updateMany({
          where: { roleId: role.id },
          data: { roleId: toKeep.id },
        })
        if (agencyMembershipCount.count > 0) {
          console.log(`      ↪ Reassigned ${agencyMembershipCount.count} agency membership(s)`)
        }
        
        // Reassign subaccount memberships to the new role
        const subAccountMembershipCount = await db.subAccountMembership.updateMany({
          where: { roleId: role.id },
          data: { roleId: toKeep.id },
        })
        if (subAccountMembershipCount.count > 0) {
          console.log(`      ↪ Reassigned ${subAccountMembershipCount.count} subaccount membership(s)`)
        }
        
        // Delete role permissions
        await db.rolePermission.deleteMany({
          where: { roleId: role.id },
        })
        
        // Finally, delete the role
        await db.role.delete({
          where: { id: role.id },
        })
      }
      
      console.log(`   ✅ Cleaned up ${toDelete.length} duplicate(s)\n`)
    } else if (roles.length === 1) {
      console.log(`✓ "${roleName}" - no duplicates\n`)
    } else {
      console.log(`⚠️  "${roleName}" - not found!\n`)
    }
  }

  console.log('🎉 Cleanup completed!')
}

main()
  .catch((e) => {
    console.error('❌ Error cleaning up roles:', e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })

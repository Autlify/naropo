# Stripe Sync Scripts

Scripts to synchronize Stripe products, prices, and manage connected accounts.

## Prerequisites

Ensure your `.env` file has:
```bash
STRIPE_SECRET_KEY=sk_test_...
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
NEXT_PUBLIC_STRIPE_CLIENT_ID=ca_...  # For Stripe Connect
```

## Quick Start - New Stripe Account Setup

When switching to a new Stripe test account:

```bash
# 1. Update your .env file with new Stripe keys
# 2. Reset old connected accounts (fixes "no access to acct_xxx" errors)
bun scripts/reset-stripe-connections.ts

# 3. Verify the new account is accessible
bun scripts/setup-stripe-account.ts --verify

# 4. Set up products and prices
bun scripts/setup-stripe-account.ts

# 5. Regenerate Prisma client
bunx prisma generate
```

## Scripts

### 1. Setup Stripe Account (`setup-stripe-account.ts`)

Full account setup script that creates products, prices, and verifies configuration.

**Usage:**
```bash
# Verify account access only
bun scripts/setup-stripe-account.ts --verify

# Dry run (preview changes)
bun scripts/setup-stripe-account.ts --dry-run

# Full setup (create products and prices)
bun scripts/setup-stripe-account.ts

# Reset and recreate everything
bun scripts/setup-stripe-account.ts --reset
```

**What it does:**
1. ✅ Verifies Stripe API access and displays account info
2. ✅ Checks required environment variables
3. ✅ Creates/updates main Autlify product
4. ✅ Creates/updates pricing tiers
5. ✅ Creates/updates add-on products
6. ✅ Updates `constants.ts` with new IDs
7. ✅ Saves backup of Stripe config to `.env.stripe.backup`

---

### 2. Reset Stripe Connections (`reset-stripe-connections.ts`)

Clears connected account IDs from the database. **Use this when:**
- Switching to a new Stripe account
- Fixing "no access to acct_xxx" errors
- Testing Connect flows from scratch

**Usage:**
```bash
# Dry run (preview what would be reset)
bun scripts/reset-stripe-connections.ts --dry-run

# Reset all connections
bun scripts/reset-stripe-connections.ts

# Reset agency connections only
bun scripts/reset-stripe-connections.ts --agency

# Reset subaccount connections only
bun scripts/reset-stripe-connections.ts --subaccount
```

**What it clears:**
- `SubAccount.connectAccountId` - Connected account IDs
- `Agency.customerId` - Stripe customer IDs
- `Subscription` records - Old subscription data

---

### 3. Sync Stripe Product (`sync-stripe-product.ts`)

Creates or updates the Autlify product in Stripe and writes the product ID to `.env`.

**Usage:**
```bash
# Dry run (preview changes without making them)
bun scripts/sync-stripe-product.ts --dry-run

# Execute changes
bun scripts/sync-stripe-product.ts
```

**What it does:**
- Searches for existing "Autlify" product in Stripe
- Creates new product if not found
- Updates product if found
- Writes `NEXT_AUTLIFY_PRODUCT_ID` to `.env`

---

### 4. Sync Stripe Prices (`sync-stripe-prices.ts`)

Reads pricing configuration from `src/lib/constants.ts`, creates/updates prices in Stripe (MYR currency), and writes back price IDs.

**Usage:**
```bash
# Dry run (preview changes without making them)
bun scripts/sync-stripe-prices.ts --dry-run

# Execute changes
bun scripts/sync-stripe-prices.ts
```

**What it does:**
1. Reads `pricingCards` from `src/lib/constants.ts`
2. Filters out free tiers
3. Ensures product exists (calls `sync-stripe-product.ts`)
4. For each paid tier:
   - Searches for existing price in Stripe
   - Creates new price if not found
   - Updates price if amount changed (deactivates old, creates new)
5. Writes price IDs back to:
   - `src/lib/constants.ts` (priceId field)
   - `prisma/schema.prisma` (Plan enum)

**After running:**
```bash
bun prisma generate  # Regenerate Prisma client with updated Plan enum
bun run build       # Verify everything compiles
```

---

### 5. Sync Stripe Add-ons (`sync-stripe-addons.ts`)

Syncs add-on products from `addOnProducts` in `constants.ts`.

**Usage:**
```bash
bun scripts/sync-stripe-addons.ts --dry-run
bun scripts/sync-stripe-addons.ts
```

---

### 6. Sync Stripe Credits (`sync-stripe-credits.ts`)

Syncs credit-based products for usage-based billing.

**Usage:**
```bash
bun scripts/sync-stripe-credits.ts --dry-run
bun scripts/sync-stripe-credits.ts
```

---

## Common Issues

### "No access to acct_xxx"

This error occurs when the database contains connected account IDs from a different Stripe platform.

**Fix:**
```bash
# 1. Reset all connections
bun scripts/reset-stripe-connections.ts

# 2. Update .env with correct Stripe keys

# 3. Verify access
bun scripts/setup-stripe-account.ts --verify

# 4. Users need to re-connect their Stripe accounts
```

### "Invalid API key"

Your `STRIPE_SECRET_KEY` is incorrect or expired.

**Fix:**
1. Go to https://dashboard.stripe.com/apikeys
2. Copy your Secret Key (sk_test_xxx for test mode)
3. Update `STRIPE_SECRET_KEY` in `.env`

### Stripe Connect Not Working

**Checklist:**
1. ✅ `NEXT_PUBLIC_STRIPE_CLIENT_ID` is set (ca_xxx)
2. ✅ OAuth redirect URLs are configured in Stripe Dashboard
3. ✅ Connect is enabled in your Stripe account

**Configure OAuth redirects:**
1. Go to https://dashboard.stripe.com/settings/connect
2. Add redirect URLs:
   - `https://your-domain.com/agency/*/launchpad`
   - `https://your-domain.com/subaccount/*/launchpad`

---

## Price Configuration

Prices are configured in `src/lib/constants.ts`:

```typescript
export const pricingCards = [
  {
    title: 'Starter',
    price: 'RM 79',      // Will be converted to 7900 cents
    duration: 'month',   // 'month' or 'year'
    priceId: '',         // Will be populated by sync script
    // ...
  },
  // ...
]
```

**Supported price formats:**
- `RM 49` → 4900 cents (MYR)
- `$99` → 9900 cents
- `RM 1,299` → 129900 cents
- `Free` → Skipped (no Stripe price created)

---

## Workflow

### Initial Setup (New Stripe Account)
```bash
# 1. Update .env with new Stripe keys
# 2. Reset old connections
bun scripts/reset-stripe-connections.ts

# 3. Full setup
bun scripts/setup-stripe-account.ts

# 4. Regenerate Prisma client
bunx prisma generate

# 5. Build and test
bun run build
```

### Updating Prices
```bash
# 1. Edit src/lib/constants.ts (change price values)
# 2. Preview changes
bun scripts/sync-stripe-prices.ts --dry-run

# 3. Apply changes
bun scripts/sync-stripe-prices.ts

# 4. Regenerate and rebuild
bunx prisma generate
bun run build
```

---

## Dry Run Mode

Use `--dry-run` flag to preview what would happen without making any changes:

- ✅ Reads from Stripe
- ✅ Shows what would be created/updated
- ❌ Does not create/update Stripe resources
- ❌ Does not modify local files (.env, constants.ts, schema.prisma)

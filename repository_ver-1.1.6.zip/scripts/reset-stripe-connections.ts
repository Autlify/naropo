#!/usr/bin/env bun
/**
 * Reset Stripe Connected Accounts Script
 * 
 * This script resets all Stripe Connect relationships in the database.
 * Use this when switching to a new Stripe account to clear stale connected account IDs.
 * 
 * The "no access to acct_xxx" error occurs when the database contains connected account IDs
 * from a different Stripe platform account than the one currently configured.
 * 
 * Usage:
 *   bun ./scripts/reset-stripe-connections.ts           # Reset all connections
 *   bun ./scripts/reset-stripe-connections.ts --dry-run # Preview changes
 *   bun ./scripts/reset-stripe-connections.ts --agency  # Reset agency connections only
 *   bun ./scripts/reset-stripe-connections.ts --subaccount # Reset subaccount connections only
 * 
 * What this script does:
 *   1. Clears SubAccount.connectAccountId for all sub-accounts
 *   2. Clears Agency.customerId for all agencies (optional)
 *   3. Removes Subscription records tied to old Stripe customers
 * 
 * After running this script:
 *   1. Users will need to re-link their Stripe accounts via the Connect flow
 *   2. Subscriptions will need to be re-created
 */

import { db } from '../src/lib/db'

const isDryRun = process.argv.includes('--dry-run')
const agencyOnly = process.argv.includes('--agency')
const subaccountOnly = process.argv.includes('--subaccount')

interface ResetStats {
  subaccountsReset: number
  agenciesReset: number
  subscriptionsDeleted: number
}

async function resetStripeConnections(): Promise<ResetStats> {
  console.log('\n🔄 Stripe Connection Reset Script')
  console.log('==================================\n')

  if (isDryRun) {
    console.log('🔍 DRY RUN MODE - No changes will be made\n')
  }

  const stats: ResetStats = {
    subaccountsReset: 0,
    agenciesReset: 0,
    subscriptionsDeleted: 0,
  }

  try {
    // 1. Reset SubAccount connections
    if (!agencyOnly) {
      console.log('📦 Checking SubAccount connections...')
      
      const subaccountsWithConnect = await db.subAccount.findMany({
        where: {
          connectAccountId: { not: null },
        },
        select: {
          id: true,
          name: true,
          connectAccountId: true,
        },
      })

      console.log(`   Found ${subaccountsWithConnect.length} sub-accounts with Connect IDs`)

      if (subaccountsWithConnect.length > 0) {
        for (const sa of subaccountsWithConnect) {
          console.log(`   - ${sa.name}: ${sa.connectAccountId}`)
        }

        if (!isDryRun) {
          const result = await db.subAccount.updateMany({
            where: {
              connectAccountId: { not: null },
            },
            data: {
              connectAccountId: null,
            },
          })
          stats.subaccountsReset = result.count
          console.log(`   ✅ Reset ${result.count} sub-account(s)`)
        } else {
          stats.subaccountsReset = subaccountsWithConnect.length
          console.log(`   [DRY RUN] Would reset ${subaccountsWithConnect.length} sub-account(s)`)
        }
      }
    }

    // 2. Reset Agency customer IDs and subscriptions
    if (!subaccountOnly) {
      console.log('\n📦 Checking Agency customer connections...')
      
      const agenciesWithCustomer = await db.agency.findMany({
        where: {
          customerId: { not: '' },
        },
        select: {
          id: true,
          name: true,
          customerId: true,
        },
      })

      console.log(`   Found ${agenciesWithCustomer.length} agencies with Customer IDs`)

      if (agenciesWithCustomer.length > 0) {
        for (const agency of agenciesWithCustomer) {
          console.log(`   - ${agency.name}: ${agency.customerId}`)
        }

        // Delete subscriptions first (foreign key constraint)
        console.log('\n📦 Checking Subscriptions...')
        
        const subscriptions = await db.subscription.findMany({
          select: {
            id: true,
            agencyId: true,
            subscritiptionId: true,
            priceId: true,
            status: true,
          },
        })

        console.log(`   Found ${subscriptions.length} subscription(s)`)

        if (subscriptions.length > 0) {
          for (const sub of subscriptions) {
            console.log(`   - Agency ${sub.agencyId}: ${sub.subscritiptionId} (${sub.status})`)
          }

          if (!isDryRun) {
            const deleteResult = await db.subscription.deleteMany({})
            stats.subscriptionsDeleted = deleteResult.count
            console.log(`   ✅ Deleted ${deleteResult.count} subscription(s)`)
          } else {
            stats.subscriptionsDeleted = subscriptions.length
            console.log(`   [DRY RUN] Would delete ${subscriptions.length} subscription(s)`)
          }
        }

        // Now reset agency customer IDs
        if (!isDryRun) {
          const result = await db.agency.updateMany({
            where: {
              customerId: { not: '' },
            },
            data: {
              customerId: '',
            },
          })
          stats.agenciesReset = result.count
          console.log(`\n   ✅ Reset ${result.count} agency customer ID(s)`)
        } else {
          stats.agenciesReset = agenciesWithCustomer.length
          console.log(`\n   [DRY RUN] Would reset ${agenciesWithCustomer.length} agency customer ID(s)`)
        }
      }
    }

    return stats
  } catch (error) {
    console.error('❌ Error resetting connections:', error)
    throw error
  }
}

async function main() {
  try {
    const stats = await resetStripeConnections()

    console.log('\n📊 Summary')
    console.log('==========')
    console.log(`   Sub-accounts reset: ${stats.subaccountsReset}`)
    console.log(`   Agencies reset: ${stats.agenciesReset}`)
    console.log(`   Subscriptions deleted: ${stats.subscriptionsDeleted}`)

    if (isDryRun) {
      console.log('\n🔍 DRY RUN completed - no changes were made')
      console.log('   Run without --dry-run to apply changes')
    } else {
      console.log('\n✅ Reset complete!')
      console.log('\n📋 Next steps:')
      console.log('   1. Configure your new Stripe account keys in .env:')
      console.log('      - STRIPE_SECRET_KEY=sk_test_xxx')
      console.log('      - NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_xxx')
      console.log('      - NEXT_PUBLIC_STRIPE_CLIENT_ID=ca_xxx')
      console.log('   2. Run: bun ./scripts/setup-stripe-account.ts')
      console.log('   3. Users will need to re-connect their Stripe accounts')
    }

    await db.$disconnect()
    process.exit(0)
  } catch (error) {
    console.error('\n❌ Script failed:', error)
    await db.$disconnect()
    process.exit(1)
  }
}

main()

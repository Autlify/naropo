#!/usr/bin/env bun
/**
 * Sync Stripe Products & Prices
 * 
 * Single script to sync all products (plans, addons) and prices to Stripe.
 * Uses ONLY registry sources - NO other files.
 * 
 * Sources:
 *   - Plan/Addon Products: @/lib/registry/plans/plan-entitlements.ts (PLANS, ADDONS)
 *   - Prices: @/lib/registry/plans/pricing-config.ts (PRICING_CONFIG)
 * 
 * Usage:
 *   bun scripts/sync-stripe.ts              # Full sync - creates products & prices, auto-updates config files
 *   bun scripts/sync-stripe.ts --dry-run    # Preview changes (no files modified)
 *   bun scripts/sync-stripe.ts --no-update  # Sync without auto-updating config files
 * 
 * What it does:
 *   1. Creates/updates Stripe Products from PLANS and ADDONS
 *   2. Creates prices for products that don't have real Stripe price IDs
 *   3. AUTO-UPDATES pricing-config.ts with real Stripe price IDs
 *   4. AUTO-UPDATES plan-entitlements.ts PLAN_IDS with real Stripe price IDs
 */

import { stripe } from '../src/lib/stripe'
import { PRICING_CONFIG } from '../src/lib/registry/plans/pricing-config'
import * as fs from 'fs'
import * as path from 'path'
import Stripe from 'stripe'
import { PricingConfig } from '@/types/billing'

// CLI flags
const isDryRun = process.argv.includes('--dry-run')
const noUpdate = process.argv.includes('--no-update')
const shouldUpdateConfig = !isDryRun && !noUpdate // Auto-update by default unless --dry-run or --no-update

// Paths to registry files
const PRICING_CONFIG_PATH = path.resolve(__dirname, '../src/lib/registry/plans/pricing-config.ts')
const PLAN_ENTITLEMENTS_PATH = path.resolve(__dirname, '../src/lib/registry/plans/plan-entitlements.ts')
const PRISMA_SCHEMA_PATH = path.resolve(__dirname, '../prisma/schema.prisma')

// ============================================================================
// Logging Helpers
// ============================================================================

function logStep(message: string) {
    console.log(`\n${'='.repeat(60)}`)
    console.log(`  ${message}`)
    console.log('='.repeat(60))
}

function logSuccess(message: string) {
    console.log(`  ✅ ${message}`)
}

function logWarning(message: string) {
    console.log(`  ⚠️  ${message}`)
}

function logInfo(message: string) {
    console.log(`  ℹ️  ${message}`)
}

function logDryRun(message: string) {
    console.log(`  [DRY RUN] ${message}`)
}

function logCreated(message: string) {
    console.log(`  🆕 ${message}`)
}

// ============================================================================
// Types
// ============================================================================

interface ProductSyncResult {
    key: string
    name: string
    stripeProductId: string
    action: 'created' | 'updated' | 'unchanged' | 'would-create' | 'would-update'
}

interface PriceSyncResult {
    key: string
    name: string
    stripeProductId: string
    stripePriceId: string
    amount: number
    action: 'created' | 'verified' | 'would-create' | 'mismatch'
    message?: string
}

interface SyncResult {
    products: Array<{
        localId: string
        stripeId: string
        name: string
        action: 'created' | 'updated' | 'unchanged' | 'would-create' | 'would-update'
    }>
    prices: Array<{
        localId: string
        stripeId: string
        nickname: string
        productId: string
        action: 'created' | 'updated' | 'unchanged' | 'would-create' | 'would-update'
    }>
}

// ============================================================================
// Product Sync (Plans + Addons)
// ============================================================================

// Map to store created product IDs for price creation
const productIdMap = new Map<string, string>()

async function syncProducts(): Promise<ProductSyncResult[]> {
    logStep('Syncing Products')





    const results: ProductSyncResult[] = []
    // Build items from PRICING_CONFIG (SSoT) - filter by type
    const allItems = Object.entries(PRICING_CONFIG).map(([key, config]) => ({
        key,
        name: config.name,
        description: config.description,
        type: config.type as 'plan' | 'addon',
        metadata: config.type === 'plan'
            ? { category: 'plan', tier: String(config.tier ?? 0) }
            : { category: 'addon', module: key.toLowerCase() },
    }))

    // Fetch existing products from Stripe
    const stripeProducts = new Map<string, any>()
    let hasMore = true
    let startingAfter: string | undefined

    while (hasMore) {
        const response = await stripe.products.list({
            limit: 100,
            starting_after: startingAfter,
        })

        for (const product of response.data) {
            stripeProducts.set(product.name, product)
            if (product.metadata?.registryKey) {
                stripeProducts.set(product.metadata.registryKey, product)
            }
        }

        hasMore = response.has_more
        if (response.data.length > 0) {
            startingAfter = response.data[response.data.length - 1].id
        }
    }

    logInfo(`Found ${stripeProducts.size} existing products in Stripe`)

    for (const item of allItems) {
        logInfo(`Processing: ${item.name} (${item.key})`)

        let existing = stripeProducts.get(item.name) || stripeProducts.get(item.key)

        if (existing) {
            logSuccess(`Found existing: ${existing.id}`)
            productIdMap.set(item.key, existing.id)

            const needsUpdate =
                existing.description !== item.description ||
                existing.metadata?.registryKey !== item.key ||
                existing.active !== true

            if (needsUpdate) {
                if (!isDryRun) {
                    // Build metadata without undefined values
                    const newMetadata: Record<string, string> = {
                        ...existing.metadata,
                        category: item.metadata.category,
                        registryKey: item.key,
                    }
                    if (item.metadata.tier) newMetadata.tier = item.metadata.tier
                    if (item.metadata.module) newMetadata.module = item.metadata.module

                    existing = await stripe.products.update(existing.id, {
                        description: item.description,
                        active: true,
                        metadata: newMetadata,
                    })
                    logSuccess(`Updated: ${existing.id}`)
                    results.push({ key: item.key, name: item.name, stripeProductId: existing.id, action: 'updated' })
                } else {
                    logDryRun(`Would update: ${existing.id}`)
                    results.push({ key: item.key, name: item.name, stripeProductId: existing.id, action: 'would-update' })
                }
            } else {
                results.push({ key: item.key, name: item.name, stripeProductId: existing.id, action: 'unchanged' })
            }
        } else {
            // Create new product
            if (!isDryRun) {
                // Build metadata without undefined values
                const newMetadata: Record<string, string> = {
                    category: item.metadata.category,
                    registryKey: item.key,
                }
                if (item.metadata.tier) newMetadata.tier = item.metadata.tier
                if (item.metadata.module) newMetadata.module = item.metadata.module

                const created = await stripe.products.create({
                    name: item.name,
                    description: item.description,
                    active: true,
                    metadata: newMetadata,
                })
                logCreated(`Created product: ${created.id}`)
                productIdMap.set(item.key, created.id)
                results.push({ key: item.key, name: item.name, stripeProductId: created.id, action: 'created' })
            } else {
                logDryRun(`Would create: ${item.name}`)
                results.push({ key: item.key, name: item.name, stripeProductId: 'NEW', action: 'would-create' })
            }
        }
    }

    return results
}

// ============================================================================
// Price Sync - Creates prices when missing
// ============================================================================

function isPlaceholderPriceId(priceId: string | undefined): boolean {
    if (!priceId) return true
    return priceId.includes('placeholder') || priceId.startsWith('price_') === false
}

async function syncPrices(): Promise<PriceSyncResult[]> {
    logStep('Syncing Prices')

    const results: PriceSyncResult[] = []

    // Get pricing entries that need sync (including tiered pricing)
    const priceEntries = Object.entries(PRICING_CONFIG)
        .filter(([_, config]) => config.baseAmount > 0 || config.billingScheme === 'tiered_graduated')
        .map(([key, config]) => ({
            key,
            name: config.name,
            stripePriceId: config.stripePriceId,
            amount: config.baseAmount,
            currency: config.currency.toLowerCase(),
            interval: config.interval,
            isRecurring: config.interval !== 'one_time',
            // For yearly plans, use the base product (STARTER_YEARLY -> STARTER)
            productKey: key.replace('_YEARLY', ''),
            // Tiered pricing support
            billingScheme: config.billingScheme,
            // Not all pricing configs have tiers
            tiers: 'tiers' in config ? config.tiers : undefined,
        }))

    logInfo(`Processing ${priceEntries.length} prices from registry`)

    for (const entry of priceEntries) {
        logInfo(`Checking: ${entry.name} (${entry.key})`)

        // Look up product by base key (yearly plans share product with monthly)
        const productId = productIdMap.get(entry.productKey) || productIdMap.get(entry.key)
        if (!productId && !isDryRun) {
            logWarning(`No product found for ${entry.key} (productKey: ${entry.productKey}) - skipping price`)
            continue
        }

        // Check if price exists and is real (not placeholder)
        if (!isPlaceholderPriceId(entry.stripePriceId)) {
            try {
                const existingPrice = await stripe.prices.retrieve(entry.stripePriceId!)

                const isTieredEntry = entry.billingScheme === 'tiered_graduated'

                // Stripe tiered prices have unit_amount = null. Verify using billing_scheme/tiers_mode (+ tiers when present)
                if (isTieredEntry) {
                    const expectedTiersMode = 'graduated'
                    const stripeTiersMode = (existingPrice as any).tiers_mode

                    const recurringOk = entry.isRecurring
                        ? (existingPrice as any).recurring?.interval === entry.interval
                        : !(existingPrice as any).recurring

                    const basicOk =
                        existingPrice.billing_scheme === 'tiered' &&
                        stripeTiersMode === expectedTiersMode &&
                        recurringOk

                    // Compare tiers if Stripe returned them; otherwise, fall back to basic verification
                    const stripeTiers = (existingPrice as any).tiers as any[] | undefined
                    const registryTiers = entry.tiers as any[] | undefined

                    const normalizeTier = (t: any) => ({
                        up_to: t?.up_to ?? t?.upTo,
                        flat_amount: t?.flat_amount ?? t?.flatAmount,
                        unit_amount: t?.unit_amount ?? t?.unitAmount,
                    })

                    const tiersOk =
                        stripeTiers && registryTiers
                            ? JSON.stringify(stripeTiers.map(normalizeTier)) ===
                              JSON.stringify(registryTiers.map(normalizeTier))
                            : true

                    if (basicOk && tiersOk) {
                        logSuccess(`Verified: ${existingPrice.id} = tiered (${stripeTiers?.length ?? registryTiers?.length ?? 0} tiers)`)
                        results.push({
                            key: entry.key,
                            name: entry.name,
                            stripeProductId: productId || '',
                            stripePriceId: existingPrice.id,
                            amount: entry.amount,
                            action: 'verified',
                        })
                        continue
                    }

                    const msgParts: string[] = []
                    msgParts.push(`Stripe.billing_scheme=${existingPrice.billing_scheme}`)
                    msgParts.push(`Stripe.tiers_mode=${stripeTiersMode}`)
                    if (entry.isRecurring) msgParts.push(`Stripe.interval=${(existingPrice as any).recurring?.interval}`)
                    if (stripeTiers && registryTiers) msgParts.push(`Stripe.tiers=${stripeTiers.length}, Registry.tiers=${registryTiers.length}`)
                    msgParts.push(`Registry.billingScheme=${entry.billingScheme}`)

                    logWarning(`Mismatch: ${msgParts.join(', ')}`)
                    results.push({
                        key: entry.key,
                        name: entry.name,
                        stripeProductId: productId || '',
                        stripePriceId: existingPrice.id,
                        amount: entry.amount,
                        action: 'mismatch',
                        message: msgParts.join(', '),
                    })
                    continue
                }

                // Flat/per-unit pricing verification
                if (typeof existingPrice.unit_amount === 'number' && existingPrice.unit_amount === entry.amount) {
                    logSuccess(`Verified: ${existingPrice.id} = ${existingPrice.unit_amount} cents`)
                    results.push({
                        key: entry.key,
                        name: entry.name,
                        stripeProductId: productId || '',
                        stripePriceId: existingPrice.id,
                        amount: existingPrice.unit_amount || 0,
                        action: 'verified',
                    })
                    continue
                }

                logWarning(`Mismatch: Stripe has ${existingPrice.unit_amount}, registry says ${entry.amount}`)
                results.push({
                    key: entry.key,
                    name: entry.name,
                    stripeProductId: productId || '',
                    stripePriceId: existingPrice.id,
                    amount: typeof existingPrice.unit_amount === 'number' ? existingPrice.unit_amount : 0,
                    action: 'mismatch',
                    message: `Stripe=${existingPrice.unit_amount}, Registry=${entry.amount}`,
                })
                continue
            } catch (error: any) {
                if (error.code !== 'resource_missing') throw error
                // Price not found - will create below
            }
        }

        // Price doesn't exist or is placeholder - create it
        if (!isDryRun) {
            let priceParams: any = {
                product: productId,
                currency: entry.currency,
                metadata: { registryKey: entry.key },
            }

            // Handle tiered vs flat pricing
            if (entry.billingScheme === 'tiered_graduated') {
                // Tiered pricing (e.g., ENTERPRISE)
                priceParams.billing_scheme = 'tiered'
                priceParams.tiers_mode = entry.billingScheme === 'tiered_graduated' ? 'graduated' : 'volume'
                priceParams.tiers = entry.tiers?.map((t: any) => ({
                    up_to: t.upTo === 'inf' || t.upTo === Infinity ? 'inf' : t.upTo,
                    ...(t.flatAmount !== undefined && { flat_amount: t.flatAmount }),
                    ...(t.unitAmount !== undefined && { unit_amount: t.unitAmount }),
                }))
                logInfo(`Creating tiered price for ${entry.key} with ${entry.tiers?.length} tiers`)
            } else {
                // Flat or per-unit pricing
                priceParams.unit_amount = entry.amount
            }

            if (entry.isRecurring) {
                priceParams.recurring = { interval: entry.interval }
            }

            const newPrice = await stripe.prices.create(priceParams)
            const priceDesc = entry.billingScheme?.includes('tiered')
                ? `tiered (${entry.tiers?.length} tiers)`
                : `${entry.amount} ${entry.currency}`
            logCreated(`Created price: ${newPrice.id} (${priceDesc})`)

            results.push({
                key: entry.key,
                name: entry.name,
                stripeProductId: productId || '',
                stripePriceId: newPrice.id,
                amount: entry.amount,
                action: 'created',
            })
        } else {
            const priceDesc = entry.billingScheme?.includes('tiered')
                ? `tiered (${entry.tiers?.length} tiers)`
                : `${entry.amount} ${entry.currency}`
            logDryRun(`Would create price: ${priceDesc} for ${entry.name}`)
            results.push({
                key: entry.key,
                name: entry.name,
                stripeProductId: productId || 'NEW',
                stripePriceId: 'NEW',
                amount: entry.amount,
                action: 'would-create',
            })
        }
    }

    return results
}

// ============================================================================
// Update pricing-config.ts with real Stripe IDs
// ============================================================================

function updatePricingConfig(priceResults: PriceSyncResult[]): number {
    const createdPrices = priceResults.filter(r => r.action === 'created')
    if (createdPrices.length === 0) {
        return 0
    }

    let content = fs.readFileSync(PRICING_CONFIG_PATH, 'utf-8')
    let updatedCount = 0

    for (const price of createdPrices) {
        // Find the key's block and then update stripePriceId within it
        // The config has nested objects, so we need to find the key block boundaries first
        const keyPattern = new RegExp(`(\\b${price.key}:\\s*\\{)`)
        const keyMatch = keyPattern.exec(content)

        if (!keyMatch) {
            logWarning(`[pricing-config.ts] Could not find key block: ${price.key}`)
            continue
        }

        // Find the position of this key's block
        const blockStart = keyMatch.index
        // Find the stripePriceId line after this key (within reasonable distance)
        const blockSlice = content.slice(blockStart, blockStart + 3000) // Generous slice for nested objects
        
        // Match stripePriceId line within this slice
        const priceIdPattern = /(stripePriceId:\s*['"])[^'"]+(['"])/
        const priceIdMatch = priceIdPattern.exec(blockSlice)

        if (priceIdMatch) {
            // Calculate absolute position and replace
            const absoluteStart = blockStart + priceIdMatch.index
            const absoluteEnd = absoluteStart + priceIdMatch[0].length
            const newPriceIdLine = `${priceIdMatch[1]}${price.stripePriceId}${priceIdMatch[2]}`
            
            content = content.slice(0, absoluteStart) + newPriceIdLine + content.slice(absoluteEnd)
            logSuccess(`[pricing-config.ts] Updated ${price.key}: ${price.stripePriceId}`)
            updatedCount++
        } else {
            logWarning(`[pricing-config.ts] Could not find stripePriceId in ${price.key} block`)
        }
    }

    if (updatedCount > 0) {
        fs.writeFileSync(PRICING_CONFIG_PATH, content)
    }

    return updatedCount
}

// ============================================================================
// Update plan-entitlements.ts PLAN_IDS with real Stripe IDs
// ============================================================================

function updatePlanEntitlements(priceResults: PriceSyncResult[]): number {
    const createdPrices = priceResults.filter(r => r.action === 'created')
    if (createdPrices.length === 0) {
        return 0
    }

    let content = fs.readFileSync(PLAN_ENTITLEMENTS_PATH, 'utf-8')
    let updatedCount = 0

    for (const price of createdPrices) {
        // Find and replace in PLAN_IDS constant
        // Pattern: KEY: 'old_value', or KEY: "old_value",
        const patterns = [
            new RegExp(`(${price.key}:\\s*')[^']+(')`),
            new RegExp(`(${price.key}:\\s*")[^"]+(")`),
        ]

        for (const pattern of patterns) {
            if (pattern.test(content)) {
                content = content.replace(pattern, `$1${price.stripePriceId}$2`)
                logSuccess(`[plan-entitlements.ts] Updated ${price.key}: ${price.stripePriceId}`)
                updatedCount++
                break
            }
        }
    }

    if (updatedCount > 0) {
        fs.writeFileSync(PLAN_ENTITLEMENTS_PATH, content)
    }

    return updatedCount
}

// ============================================================================
// Update Prisma schema.prisma enum Plan with real Stripe IDs
// ============================================================================

// Plan keys that go into Prisma enum Plan (subscriptions only, not one-time addons)
const PLAN_KEYS_FOR_PRISMA = [
    'STARTER', 'BASIC', 'ADVANCED', 'ENTERPRISE',
    'STARTER_YEARLY', 'BASIC_YEARLY', 'ADVANCED_YEARLY', 'ENTERPRISE_YEARLY'
]

function updatePrismaEnumPlan(priceResults: PriceSyncResult[]): number {
    logInfo('Checking Prisma schema enum Plan...')

    // Get all verified/created plan prices (not addons)
    const planPrices = priceResults.filter(r =>
        PLAN_KEYS_FOR_PRISMA.includes(r.key) &&
        (r.action === 'verified' || r.action === 'created')
    )

    if (planPrices.length === 0) {
        logInfo('No plan prices to update in Prisma enum')
        return 0
    }

    let content = fs.readFileSync(PRISMA_SCHEMA_PATH, 'utf-8')

    // Build new enum values from actual Stripe price IDs
    const enumValues = planPrices.map(p => `  ${p.stripePriceId}`).join('\n')
    const newEnumBlock = `enum Plan {\n${enumValues}\n\n  @@schema("public")\n}`

    // Find and replace existing enum Plan block
    const enumPattern = /enum Plan \{[^}]+@@schema\("public"\)\s*\}/

    if (!enumPattern.test(content)) {
        logWarning('Could not find enum Plan in Prisma schema')
        return 0
    }

    // Check if update is needed
    const currentMatch = content.match(enumPattern)
    if (currentMatch && currentMatch[0] === newEnumBlock) {
        logInfo('Prisma enum Plan already up to date')
        return 0
    }

    content = content.replace(enumPattern, newEnumBlock)
    fs.writeFileSync(PRISMA_SCHEMA_PATH, content)

    logSuccess(`[schema.prisma] Updated enum Plan with ${planPrices.length} price IDs:`)
    for (const p of planPrices) {
        console.log(`    - ${p.key}: ${p.stripePriceId}`)
    }

    return planPrices.length
}

// ============================================================================
// Auto-update all config files
// ============================================================================

function autoUpdateConfigFiles(priceResults: PriceSyncResult[]): void {
    logStep('Auto-updating Config Files')

    logInfo('Files to update:')
    console.log('    1. src/lib/registry/plans/pricing-config.ts')
    console.log('    2. src/lib/registry/plans/plan-entitlements.ts')
    console.log('    3. prisma/schema.prisma (enum Plan)')
    console.log('')

    const createdPrices = priceResults.filter(r => r.action === 'created')

    // Update pricing-config.ts (only for newly created)
    if (createdPrices.length > 0) {
        logInfo(`Updating pricing-config.ts with ${createdPrices.length} new prices...`)
        const pricingUpdates = updatePricingConfig(priceResults)
        if (pricingUpdates > 0) {
            logSuccess(`Updated ${pricingUpdates} price IDs in pricing-config.ts`)
        }

        logInfo(`Updating plan-entitlements.ts with ${createdPrices.length} new prices...`)
        const entitlementsUpdates = updatePlanEntitlements(priceResults)
        if (entitlementsUpdates > 0) {
            logSuccess(`Updated ${entitlementsUpdates} price IDs in plan-entitlements.ts`)
        }
    } else {
        logInfo('No new prices - pricing-config.ts and plan-entitlements.ts already current')
    }

    // Always update Prisma enum with verified price IDs
    logInfo('Updating prisma/schema.prisma enum Plan...')
    const prismaUpdates = updatePrismaEnumPlan(priceResults)

    const totalNew = createdPrices.length
    console.log('')
    console.log(`  📝 Summary:`)
    console.log(`     - New prices created: ${totalNew}`)
    console.log(`     - Prisma enum updated: ${prismaUpdates > 0 ? 'Yes' : 'No (already current)'}`)
}

// ============================================================================
// Main Execution
// ============================================================================

async function main() {
    try {
        console.log('🚀 Stripe Sync Script')
        console.log('   Sources: plan-entitlements.ts, pricing-config.ts')

        if (isDryRun) {
            console.log('   Mode: DRY RUN (no changes will be made)')
        } else if (noUpdate) {
            console.log('   Mode: LIVE (sync only, no config file updates)')
        } else {
            console.log('   Mode: LIVE + AUTO-UPDATE (changes will be applied & config files updated)')
        }
        console.log('')

        // 1. Sync products first (needed for price creation)
        const productResults = await syncProducts()

        // 2. Sync prices (creates missing ones)
        const priceResults = await syncPrices()

        // 3. Auto-update config files (unless --dry-run or --no-update)
        if (shouldUpdateConfig) {
            autoUpdateConfigFiles(priceResults)
        }

        // Summary
        logStep('Summary')

        console.log('\nProducts:')
        const prodCreated = productResults.filter(r => r.action === 'created' || r.action === 'would-create')
        const prodUpdated = productResults.filter(r => r.action === 'updated' || r.action === 'would-update')
        const prodUnchanged = productResults.filter(r => r.action === 'unchanged')
        console.log(`  Created: ${prodCreated.length}`)
        console.log(`  Updated: ${prodUpdated.length}`)
        console.log(`  Unchanged: ${prodUnchanged.length}`)

        console.log('\nPrices:')
        const priceCreated = priceResults.filter(r => r.action === 'created' || r.action === 'would-create')
        const priceVerified = priceResults.filter(r => r.action === 'verified')
        const priceMismatch = priceResults.filter(r => r.action === 'mismatch')
        console.log(`  Created: ${priceCreated.length}`)
        console.log(`  Verified: ${priceVerified.length}`)
        console.log(`  Mismatch: ${priceMismatch.length}`)

        // Note about manual updates if --no-update was used
        if (noUpdate && priceCreated.length > 0) {
            console.log('\n📋 New price IDs (update manually or run without --no-update):')
            console.log('─'.repeat(50))
            for (const r of priceCreated) {
                if (r.stripePriceId !== 'NEW') {
                    console.log(`  ${r.key}: '${r.stripePriceId}'`)
                }
            }
            console.log('─'.repeat(50))
        }

        if (priceMismatch.length > 0) {
            console.log('\n⚠️  Price mismatches (manual resolution needed):')
            for (const r of priceMismatch) {
                console.log(`  - ${r.key}: ${r.message}`)
            }
        }

        if (isDryRun) {
            console.log('\n🎉 DRY RUN completed - no changes were made')
            console.log('💡 Run without --dry-run to apply changes')
        } else {
            console.log('\n🎉 Sync completed!')
            if (shouldUpdateConfig && priceCreated.length > 0) {
                console.log('   Config files have been auto-updated with new Stripe price IDs')
            }
        }

    } catch (error) {
        console.error('\n❌ Error:', error)
        process.exit(1)
    }
}

main()

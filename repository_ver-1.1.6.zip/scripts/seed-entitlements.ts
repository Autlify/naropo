/**
 * Seed script for Entitlement Features and Plan Features.
 * 
 * Usage: bun run scripts/seed-entitlements.ts
 * 
 * This will:
 * 1. Upsert all EntitlementFeature records from the registry
 * 2. Upsert all PlanFeature records based on PLAN_ENTITLEMENTS
 */

import { db } from '../src/lib/db'
import { ENTITLEMENT_FEATURES } from '../src/lib/registry/keys/entitlement-features'
import { PLAN_ENTITLEMENTS } from '../src/lib/registry/plans/plan-entitlements'

async function main() {
  console.log('🌱 Seeding entitlement features...\n')

  // 1. Upsert EntitlementFeature records
  let featuresCreated = 0
  let featuresUpdated = 0

  for (const feature of ENTITLEMENT_FEATURES) {
    const existing = await db.entitlementFeature.findUnique({
      where: { key: feature.key },
    })

    if (existing) {
      await db.entitlementFeature.update({
        where: { key: feature.key },
        data: {
          name: feature.name,
          description: feature.description,
          category: feature.category,
          valueType: feature.valueType,
          unit: feature.unit,
          metering: feature.metering,
          aggregation: feature.aggregation,
          scope: feature.scope,
          period: feature.period,
          displayName: feature.displayName,
          icon: feature.icon,
          helpText: feature.helpText,
          displayOrder: feature.displayOrder ?? 0,
          isToggleable: feature.isToggleable ?? false,
          defaultEnabled: feature.defaultEnabled ?? true,
          requiresRestart: feature.requiresRestart ?? false,
          creditEnabled: feature.creditEnabled ?? false,
          creditUnit: feature.creditUnit,
          creditExpires: feature.creditExpires ?? false,
          creditPriority: feature.creditPriority ?? 100,
        },
      })
      featuresUpdated++
      console.log(`  ↻ Updated: ${feature.key}`)
    } else {
      await db.entitlementFeature.create({
        data: {
          key: feature.key,
          name: feature.name,
          description: feature.description,
          category: feature.category,
          valueType: feature.valueType,
          unit: feature.unit,
          metering: feature.metering,
          aggregation: feature.aggregation,
          scope: feature.scope,
          period: feature.period,
          displayName: feature.displayName,
          icon: feature.icon,
          helpText: feature.helpText,
          displayOrder: feature.displayOrder ?? 0,
          isToggleable: feature.isToggleable ?? false,
          defaultEnabled: feature.defaultEnabled ?? true,
          requiresRestart: feature.requiresRestart ?? false,
          creditEnabled: feature.creditEnabled ?? false,
          creditUnit: feature.creditUnit,
          creditExpires: feature.creditExpires ?? false,
          creditPriority: feature.creditPriority ?? 100,
        },
      })
      featuresCreated++
      console.log(`  ✓ Created: ${feature.key}`)
    }
  }

  console.log(`\n  Features: ${featuresCreated} created, ${featuresUpdated} updated\n`)

  // 2. Upsert PlanFeature records
  console.log('🌱 Seeding plan entitlements...\n')

  let planFeaturesCreated = 0
  let planFeaturesUpdated = 0

  for (const pf of PLAN_ENTITLEMENTS) {
    // First check if the feature exists
    const featureExists = await db.entitlementFeature.findUnique({
      where: { key: pf.featureKey },
    })

    if (!featureExists) {
      console.log(`  ⚠ Skipping: ${pf.featureKey} (feature not found)`)
      continue
    }

    const existing = await db.planFeature.findUnique({
      where: {
        planId_featureKey: {
          planId: pf.planId,
          featureKey: pf.featureKey,
        },
      },
    })

    const data = {
      isEnabled: pf.isEnabled ?? true,
      isUnlimited: pf.isUnlimited ?? false,
      includedInt: pf.includedInt ?? null,
      maxInt: pf.maxInt ?? null,
      includedDec: pf.includedDec ?? null,
      maxDec: pf.maxDec ?? null,
      enforcement: pf.enforcement ?? 'HARD',
      overageMode: pf.overageMode ?? 'NONE',
      recurringCreditGrantInt: pf.recurringCreditGrantInt ?? null,
      recurringCreditGrantDec: pf.recurringCreditGrantDec ?? null,
      rolloverCredits: pf.rolloverCredits ?? false,
      topUpEnabled: pf.topUpEnabled ?? false,
      topUpPriceId: pf.topUpPriceId ?? null,
    }

    if (existing) {
      await db.planFeature.update({
        where: {
          planId_featureKey: {
            planId: pf.planId,
            featureKey: pf.featureKey,
          },
        },
        data,
      })
      planFeaturesUpdated++
      console.log(`  ↻ Updated: ${pf.planId.slice(0, 20)}... → ${pf.featureKey}`)
    } else {
      await db.planFeature.create({
        data: {
          planId: pf.planId,
          featureKey: pf.featureKey,
          ...data,
        },
      })
      planFeaturesCreated++
      console.log(`  ✓ Created: ${pf.planId.slice(0, 20)}... → ${pf.featureKey}`)
    }
  }

  console.log(`\n  Plan features: ${planFeaturesCreated} created, ${planFeaturesUpdated} updated\n`)
  console.log('✅ Seed complete!\n')
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })

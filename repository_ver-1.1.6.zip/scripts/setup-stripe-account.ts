#!/usr/bin/env bun
/**
 * Stripe Account Setup Script
 * 
 * This script sets up or reconfigures a Stripe account with all required
 * products, prices, and configurations for Autlify.
 * 
 * Usage:
 *   bun ./scripts/setup-stripe-account.ts           # Full setup
 *   bun ./scripts/setup-stripe-account.ts --dry-run # Preview changes
 *   bun ./scripts/setup-stripe-account.ts --reset   # Reset and recreate all
 *   bun ./scripts/setup-stripe-account.ts --verify  # Only verify account access
 * 
 * Required Environment Variables:
 *   - STRIPE_SECRET_KEY: Your Stripe secret key (sk_test_xxx or sk_live_xxx)
 *   - NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY: Your Stripe publishable key (pk_test_xxx or pk_live_xxx)
 *   - NEXT_PUBLIC_STRIPE_CLIENT_ID: Your Stripe Connect OAuth client ID (ca_xxx)
 * 
 * Common Issues:
 *   - "No access to acct_xxx": The STRIPE_SECRET_KEY doesn't have access to the connected account.
 *     This usually means you're using keys from a different Stripe account than where the
 *     connected account was created. Reset the SubAccount.connectAccountId in the database
 *     and re-connect using the correct platform account.
 */

import { stripe } from '../src/lib/stripe'
import * as fs from 'fs'
import * as path from 'path'
import Stripe from 'stripe'

// ============================================================================
// CONFIGURATION - Edit these values to match your requirements
// ============================================================================

const CONFIG = {
  // Main Product
  mainProduct: {
    name: 'Autlify Platform',
    description: 'Agency management platform and CRM for modern agencies',
    metadata: {
      category: 'software',
      type: 'core_license',
    },
  },

  // Pricing Tiers (in MYR cents)
  pricingTiers: [
    {
      name: 'Starter',
      description: 'Perfect for trying out Autlify',
      amount: 7900, // RM 79
      currency: 'myr',
      interval: 'month' as const,
      trialEnabled: true,
      trialPeriodDays: 14,
      features: ['3 Sub-Accounts', '2 Team Members', 'Unlimited Pipelines'],
    },
    {
      name: 'Basic',
      description: 'For serious agency owners',
      amount: 14900, // RM 149
      currency: 'myr',
      interval: 'month' as const,
      trialEnabled: true,
      trialPeriodDays: 14,
      features: ['Unlimited Sub-Accounts', 'Unlimited Team Members'],
    },
    {
      name: 'Advanced',
      description: 'The ultimate agency kit',
      amount: 39900, // RM 399
      currency: 'myr',
      interval: 'month' as const,
      trialEnabled: false,
      trialPeriodDays: 0,
      features: ['Rebilling', '24/7 Support Team'],
    },
  ],

  // Add-on Products
  addons: [
    {
      name: 'Priority Support',
      description: '24/7 priority support with dedicated account manager',
      amount: 9900, // RM 99
      currency: 'myr',
      interval: 'month' as const,
    },
  ],

  // Webhook Events to enable (configure in Stripe Dashboard)
  webhookEvents: [
    'checkout.session.completed',
    'customer.subscription.created',
    'customer.subscription.updated',
    'customer.subscription.deleted',
    'customer.subscription.trial_will_end',
    'invoice.payment_succeeded',
    'invoice.payment_failed',
    'payment_intent.succeeded',
    'payment_intent.payment_failed',
  ],

  // Customer Portal Configuration
  customerPortal: {
    allowCancellations: true,
    allowPlanChanges: true,
    allowPaymentMethodUpdates: true,
  },
}

// ============================================================================
// SCRIPT IMPLEMENTATION
// ============================================================================

interface SetupResult {
  mainProductId: string
  prices: Array<{
    name: string
    priceId: string
    amount: number
    interval: string
  }>
  addons: Array<{
    name: string
    productId: string
    priceId: string
    amount: number
  }>
}

const isDryRun = process.argv.includes('--dry-run')
const isReset = process.argv.includes('--reset')
const isVerifyOnly = process.argv.includes('--verify')

interface StripeAccountInfo {
  id: string
  displayName: string | null
  email: string | null | undefined
  country: string | null | undefined
  livemode: boolean
  connectEnabled: boolean
}

async function verifyStripeAccount(): Promise<StripeAccountInfo | null> {
  logStep('Verifying Stripe Account Access')

  try {
    // Check environment variables
    const secretKey = process.env.STRIPE_SECRET_KEY
    const publishableKey = process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY
    const clientId = process.env.NEXT_PUBLIC_STRIPE_CLIENT_ID

    if (!secretKey) {
      console.error('  ❌ STRIPE_SECRET_KEY is not set')
      return null
    }

    if (!publishableKey) {
      logWarning('NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY is not set')
    }

    if (!clientId) {
      logWarning('NEXT_PUBLIC_STRIPE_CLIENT_ID is not set (required for Connect)')
    }

    // Verify key format
    const isTestMode = secretKey.startsWith('sk_test_')
    const isLiveMode = secretKey.startsWith('sk_live_')

    if (!isTestMode && !isLiveMode) {
      console.error('  ❌ STRIPE_SECRET_KEY format is invalid')
      console.error('     Expected: sk_test_xxx or sk_live_xxx')
      return null
    }

    logInfo(`Mode: ${isTestMode ? 'TEST' : 'LIVE'}`)

    // Verify account access
    const account = await stripe.accounts.retrieve()

    logSuccess(`Account ID: ${account.id}`)
    logSuccess(`Display Name: ${account.settings?.dashboard?.display_name || 'Not set'}`)
    
    if (account.email) {
      logSuccess(`Email: ${account.email}`)
    }
    
    if (account.country) {
      logSuccess(`Country: ${account.country}`)
    }

    // Check if Connect is enabled
    const connectEnabled = !!clientId && clientId.startsWith('ca_')
    if (connectEnabled) {
      logSuccess(`Connect Client ID: ${clientId}`)
    } else {
      logWarning('Stripe Connect is not configured')
      logInfo('To enable Connect:')
      logInfo('1. Go to https://dashboard.stripe.com/settings/connect')
      logInfo('2. Enable Connect and get your Client ID')
      logInfo('3. Set NEXT_PUBLIC_STRIPE_CLIENT_ID in .env')
    }

    // Verify webhook secret
    if (process.env.STRIPE_WEBHOOK_SECRET) {
      logSuccess('Webhook secret is configured')
    } else {
      logWarning('STRIPE_WEBHOOK_SECRET is not set')
      logInfo('Configure webhooks at: https://dashboard.stripe.com/webhooks')
    }

    // List existing products for information
    const products = await stripe.products.list({ limit: 10 })
    logInfo(`Existing products: ${products.data.length}`)

    return {
      id: account.id,
      displayName: account.settings?.dashboard?.display_name || null,
      email: account.email,
      country: account.country,
      livemode: !isTestMode,
      connectEnabled,
    }
  } catch (error: any) {
    console.error('  ❌ Failed to verify Stripe account')
    
    if (error.type === 'StripeAuthenticationError') {
      console.error('     Invalid API key. Check your STRIPE_SECRET_KEY.')
    } else if (error.code === 'account_invalid') {
      console.error('     The account associated with this API key is invalid or restricted.')
    } else {
      console.error(`     Error: ${error.message}`)
    }

    console.error('\n  To fix this:')
    console.error('  1. Go to https://dashboard.stripe.com/apikeys')
    console.error('  2. Copy your Secret Key (sk_test_xxx for test mode)')
    console.error('  3. Update STRIPE_SECRET_KEY in your .env file')

    return null
  }
}

function logStep(message: string) {
  console.log(`\n${'='.repeat(60)}`)
  console.log(`  ${message}`)
  console.log('='.repeat(60))
}

function logInfo(message: string) {
  console.log(`  ℹ️  ${message}`)
}

function logSuccess(message: string) {
  console.log(`  ✅ ${message}`)
}

function logWarning(message: string) {
  console.log(`  ⚠️  ${message}`)
}

function logDryRun(message: string) {
  console.log(`  [DRY RUN] ${message}`)
}

async function deactivateExistingPrices(productId: string): Promise<void> {
  const prices = await stripe.prices.list({
    product: productId,
    active: true,
    limit: 100,
  })

  for (const price of prices.data) {
    if (!isDryRun) {
      await stripe.prices.update(price.id, { active: false })
      logInfo(`Deactivated old price: ${price.id}`)
    } else {
      logDryRun(`Would deactivate price: ${price.id}`)
    }
  }
}

async function setupMainProduct(): Promise<string> {
  logStep('Setting up Main Product')

  // Search for existing product
  const products = await stripe.products.list({ limit: 100 })
  let product = products.data.find(p => p.name === CONFIG.mainProduct.name)

  if (isReset && product) {
    logInfo(`Found existing product: ${product.id}`)
    await deactivateExistingPrices(product.id)
  }

  if (!product) {
    if (!isDryRun) {
      product = await stripe.products.create({
        name: CONFIG.mainProduct.name,
        description: CONFIG.mainProduct.description,
        type: 'service',
        active: true,
        metadata: CONFIG.mainProduct.metadata,
      })
      logSuccess(`Created product: ${product.id}`)
    } else {
      logDryRun(`Would create product: ${CONFIG.mainProduct.name}`)
      return 'prod_DRYRUN'
    }
  } else {
    if (!isDryRun) {
      product = await stripe.products.update(product.id, {
        description: CONFIG.mainProduct.description,
        active: true,
        metadata: CONFIG.mainProduct.metadata,
      })
      logSuccess(`Updated existing product: ${product.id}`)
    } else {
      logDryRun(`Would update product: ${product.id}`)
    }
  }

  return product!.id
}

async function setupPrices(productId: string): Promise<SetupResult['prices']> {
  logStep('Setting up Pricing Tiers')

  const results: SetupResult['prices'] = []

  for (const tier of CONFIG.pricingTiers) {
    logInfo(`Processing: ${tier.name} - ${tier.amount / 100} ${tier.currency.toUpperCase()}/${tier.interval}`)

    if (!isDryRun) {
      // Check for existing price
      const existingPrices = await stripe.prices.list({
        product: productId,
        active: true,
        limit: 100,
      })

      let price = existingPrices.data.find(
        p =>
          p.nickname === tier.name &&
          p.unit_amount === tier.amount &&
          p.currency === tier.currency &&
          p.recurring?.interval === tier.interval
      )

      if (!price || isReset) {
        // Create new price
        price = await stripe.prices.create({
          product: productId,
          currency: tier.currency,
          unit_amount: tier.amount,
          nickname: tier.name,
          recurring: {
            interval: tier.interval,
            trial_period_days: tier.trialEnabled ? tier.trialPeriodDays : undefined,
          },
          active: true,
          metadata: {
            tier: tier.name.toLowerCase(),
            features: tier.features.join(', '),
          },
        })
        logSuccess(`Created price: ${price.id} (${tier.name})`)
      } else {
        logSuccess(`Found existing price: ${price.id} (${tier.name})`)
      }

      results.push({
        name: tier.name,
        priceId: price.id,
        amount: tier.amount,
        interval: tier.interval,
      })
    } else {
      logDryRun(`Would create/update price for ${tier.name}`)
      results.push({
        name: tier.name,
        priceId: `price_DRYRUN_${tier.name.toUpperCase()}`,
        amount: tier.amount,
        interval: tier.interval,
      })
    }
  }

  return results
}

async function setupAddons(): Promise<SetupResult['addons']> {
  logStep('Setting up Add-on Products')

  const results: SetupResult['addons'] = []

  for (const addon of CONFIG.addons) {
    logInfo(`Processing addon: ${addon.name}`)

    if (!isDryRun) {
      // Search for existing product
      const products = await stripe.products.list({ limit: 100 })
      let product = products.data.find(p => p.name === addon.name)

      if (!product) {
        product = await stripe.products.create({
          name: addon.name,
          description: addon.description,
          type: 'service',
          active: true,
          metadata: { type: 'addon' },
        })
        logSuccess(`Created addon product: ${product.id}`)
      } else {
        if (isReset) {
          await deactivateExistingPrices(product.id)
        }
        logSuccess(`Found existing addon product: ${product.id}`)
      }

      // Check/create price
      const existingPrices = await stripe.prices.list({
        product: product.id,
        active: true,
        limit: 100,
      })

      let price = existingPrices.data.find(
        p =>
          p.unit_amount === addon.amount &&
          p.currency === addon.currency &&
          p.recurring?.interval === addon.interval
      )

      if (!price || isReset) {
        price = await stripe.prices.create({
          product: product.id,
          currency: addon.currency,
          unit_amount: addon.amount,
          nickname: addon.name,
          recurring: { interval: addon.interval },
          active: true,
        })
        logSuccess(`Created addon price: ${price.id}`)
      } else {
        logSuccess(`Found existing addon price: ${price.id}`)
      }

      results.push({
        name: addon.name,
        productId: product.id,
        priceId: price.id,
        amount: addon.amount,
      })
    } else {
      logDryRun(`Would create addon: ${addon.name}`)
      results.push({
        name: addon.name,
        productId: `prod_DRYRUN_${addon.name.replace(/\s+/g, '_').toUpperCase()}`,
        priceId: `price_DRYRUN_${addon.name.replace(/\s+/g, '_').toUpperCase()}`,
        amount: addon.amount,
      })
    }
  }

  return results
}

function generateEnvContent(result: SetupResult): string {
  const lines = [
    '# Stripe Configuration (Auto-generated by setup-stripe-account.ts)',
    `# Generated at: ${new Date().toISOString()}`,
    '',
    '# Main Product',
    `NEXT_AUTLIFY_PRODUCT_ID="${result.mainProductId}"`,
    '',
    '# Price IDs',
    ...result.prices.map(p => `STRIPE_PRICE_${p.name.toUpperCase()}="${p.priceId}"`),
    '',
    '# Addon Product IDs',
    ...result.addons.map(a => `STRIPE_ADDON_${a.name.replace(/\s+/g, '_').toUpperCase()}_PRODUCT_ID="${a.productId}"`),
    ...result.addons.map(a => `STRIPE_ADDON_${a.name.replace(/\s+/g, '_').toUpperCase()}_PRICE_ID="${a.priceId}"`),
    '',
  ]

  return lines.join('\n')
}

function updateConstantsFile(result: SetupResult): void {
  const constantsPath = path.join(process.cwd(), 'src/lib/constants.ts')
  
  if (!fs.existsSync(constantsPath)) {
    logWarning('constants.ts not found, skipping update')
    return
  }

  let content = fs.readFileSync(constantsPath, 'utf-8')

  // Update pricing card priceIds
  for (const price of result.prices) {
    const regex = new RegExp(
      `(title: '${price.name}'[\\s\\S]*?priceId: ')([^']*)(')`,
      'g'
    )
    content = content.replace(regex, `$1${price.priceId}$3`)
  }

  // Update addon priceIds and product ids
  for (const addon of result.addons) {
    // Update product ID
    const idRegex = new RegExp(
      `(title: '${addon.name}'[\\s\\S]*?id: ')([^']*)(')`,
      'g'
    )
    content = content.replace(idRegex, `$1${addon.productId}$3`)

    // Update price ID
    const priceIdRegex = new RegExp(
      `(title: '${addon.name}'[\\s\\S]*?priceId: ')([^']*)(')`,
      'g'
    )
    content = content.replace(priceIdRegex, `$1${addon.priceId}$3`)
  }

  if (!isDryRun) {
    fs.writeFileSync(constantsPath, content)
    logSuccess('Updated constants.ts with new IDs')
  } else {
    logDryRun('Would update constants.ts')
  }
}

async function printSummary(result: SetupResult): Promise<void> {
  logStep('Setup Summary')

  console.log('\n📦 Main Product:')
  console.log(`   ID: ${result.mainProductId}`)

  console.log('\n💰 Pricing Tiers:')
  for (const price of result.prices) {
    console.log(`   ${price.name}: ${price.priceId}`)
    console.log(`      Amount: ${price.amount / 100} MYR/${price.interval}`)
  }

  console.log('\n🔌 Add-ons:')
  for (const addon of result.addons) {
    console.log(`   ${addon.name}:`)
    console.log(`      Product: ${addon.productId}`)
    console.log(`      Price: ${addon.priceId}`)
    console.log(`      Amount: ${addon.amount / 100} MYR/month`)
  }

  console.log('\n⚙️  Webhook Events to Configure:')
  for (const event of CONFIG.webhookEvents) {
    console.log(`   - ${event}`)
  }

  console.log('\n🌐 Customer Portal Settings:')
  console.log(`   - Allow cancellations: ${CONFIG.customerPortal.allowCancellations}`)
  console.log(`   - Allow plan changes: ${CONFIG.customerPortal.allowPlanChanges}`)
  console.log(`   - Allow payment method updates: ${CONFIG.customerPortal.allowPaymentMethodUpdates}`)

  // Get account info
  try {
    const account = await stripe.accounts.retrieve()
    console.log('\n🏢 Stripe Account:')
    console.log(`   Dashboard: https://dashboard.stripe.com/${account.id}`)
    console.log(`   API Keys: https://dashboard.stripe.com/${account.id}/apikeys`)
    console.log(`   Webhooks: https://dashboard.stripe.com/${account.id}/webhooks`)
    console.log(`   Products: https://dashboard.stripe.com/${account.id}/products`)
  } catch (e) {
    // Ignore if account retrieval fails
  }
}

async function main(): Promise<void> {
  console.log('\n🚀 Autlify Stripe Account Setup')
  console.log('================================\n')

  if (isDryRun) {
    console.log('🔍 DRY RUN MODE - No changes will be made\n')
  }

  if (isReset) {
    console.log('🔄 RESET MODE - Will deactivate existing prices and create new ones\n')
  }

  if (isVerifyOnly) {
    console.log('🔍 VERIFY ONLY MODE - Will only check account access\n')
  }

  try {
    // Always verify account first
    const accountInfo = await verifyStripeAccount()
    
    if (!accountInfo) {
      console.error('\n❌ Account verification failed. Cannot proceed.')
      process.exit(1)
    }

    if (isVerifyOnly) {
      console.log('\n✅ Account verification complete!')
      process.exit(0)
    }

    // Setup main product
    const mainProductId = await setupMainProduct()

    // Setup prices
    const prices = await setupPrices(mainProductId)

    // Setup addons
    const addons = await setupAddons()

    const result: SetupResult = {
      mainProductId,
      prices,
      addons,
    }

    // Update constants.ts
    logStep('Updating Code Files')
    updateConstantsFile(result)

    // Generate .env content
    const envContent = generateEnvContent(result)
    const envBackupPath = path.join(process.cwd(), '.env.stripe.backup')

    if (!isDryRun) {
      fs.writeFileSync(envBackupPath, envContent)
      logSuccess(`Saved Stripe config to ${envBackupPath}`)
    } else {
      logDryRun('Would save Stripe config to .env.stripe.backup')
    }

    // Print summary
    await printSummary(result)

    logStep('Next Steps')
    console.log('\n1. Run: bunx prisma generate')
    console.log('2. Run: bun run build')
    console.log('3. Configure webhooks in Stripe Dashboard:')
    console.log(`   URL: ${process.env.NEXT_PUBLIC_URL || 'https://your-domain.com'}/api/stripe/webhook`)
    console.log('4. Set STRIPE_WEBHOOK_SECRET in .env')
    
    if (!accountInfo.connectEnabled) {
      console.log('\n⚠️  Stripe Connect is not configured!')
      console.log('   To enable agency/subaccount connections:')
      console.log('   1. Go to https://dashboard.stripe.com/settings/connect')
      console.log('   2. Enable Connect and complete onboarding')
      console.log('   3. Get your Client ID (ca_xxx)')
      console.log('   4. Set NEXT_PUBLIC_STRIPE_CLIENT_ID in .env')
    }
    
    console.log('\n✅ Setup complete!')
  } catch (error) {
    console.error('\n❌ Setup failed:', error)
    process.exit(1)
  }
}

main()

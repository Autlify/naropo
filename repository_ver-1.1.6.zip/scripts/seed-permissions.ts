/**
 * Consolidated Permission Seeder
 * 
 * Seeds all permissions and RBAC roles from the KEYS registry (SSOT).
 * 
 * Usage: bun run scripts/seed-permissions.ts
 *        bun run scripts/seed-permissions.ts --dry-run
 * 
 * This will:
 * 1. Upsert all Permission records derived from KEYS
 * 2. Create/update system roles with their permissions
 */

import { db } from '../src/lib/db'
import { KEYS } from '../src/lib/registry/keys/permissions'
import type { ActionKey } from '../src/lib/registry/keys/actions'
import type { Permission } from '../src/generated/prisma/client'

// Check for --dry-run flag
const isDryRun = process.argv.includes('--dry-run')

// =============================================================================
// PERMISSION DEFINITIONS
// =============================================================================

type PermissionDefinition = {
    key: ActionKey
    name: string
    description: string
    category: string
}

/**
 * All permission definitions derived from KEYS with human-readable metadata.
 * Adding a new key to KEYS and here will automatically seed it.
 */
const PERMISSION_DEFINITIONS: PermissionDefinition[] = [
    // ========== CORE: Agency ==========
    { key: KEYS.core.agency.account.read, name: 'View Agency', description: 'Can view agency account and dashboard', category: 'agency' },
    { key: KEYS.core.agency.account.update, name: 'Update Agency', description: 'Can update agency details', category: 'agency' },
    { key: KEYS.core.agency.account.delete, name: 'Delete Agency', description: 'Can delete the agency', category: 'agency' },
    { key: KEYS.core.agency.subaccounts.read, name: 'View SubAccounts', description: 'Can view subaccount list', category: 'agency' },
    { key: KEYS.core.agency.subaccounts.create, name: 'Create SubAccount', description: 'Can create new subaccounts', category: 'agency' },
    { key: KEYS.core.agency.subaccounts.update, name: 'Update SubAccount', description: 'Can modify subaccount settings', category: 'agency' },
    { key: KEYS.core.agency.subaccounts.delete, name: 'Delete SubAccount', description: 'Can delete subaccounts', category: 'agency' },
    { key: KEYS.core.agency.team_member.invite, name: 'Invite Members', description: 'Can invite new team members', category: 'agency' },
    { key: KEYS.core.agency.team_member.remove, name: 'Remove Members', description: 'Can remove team members', category: 'agency' },
    { key: KEYS.core.agency.team_member.manage, name: 'Manage Members', description: 'Can manage team member roles', category: 'agency' },
    { key: KEYS.core.agency.settings.view, name: 'View Agency Settings', description: 'Can view agency settings', category: 'agency' },
    { key: KEYS.core.agency.settings.manage, name: 'Manage Agency Settings', description: 'Can modify agency settings', category: 'agency' },
    { key: KEYS.core.agency.storage.view, name: 'View Storage', description: 'Can view storage usage', category: 'agency' },
    { key: KEYS.core.agency.storage.manage, name: 'Manage Storage', description: 'Can manage storage settings', category: 'agency' },

    // ========== CORE: Billing ==========
    { key: KEYS.core.billing.account.view, name: 'View Billing Account', description: 'Can view billing account details', category: 'billing' },
    { key: KEYS.core.billing.account.manage, name: 'Manage Billing Account', description: 'Can manage billing account', category: 'billing' },
    { key: KEYS.core.billing.payment_methods.read, name: 'View Payment Methods', description: 'Can view payment methods', category: 'billing' },
    { key: KEYS.core.billing.payment_methods.create, name: 'Add Payment Methods', description: 'Can add new payment methods', category: 'billing' },
    { key: KEYS.core.billing.payment_methods.delete, name: 'Delete Payment Methods', description: 'Can delete payment methods', category: 'billing' },
    { key: KEYS.core.billing.subscription.view, name: 'View Subscription', description: 'Can view subscription details', category: 'billing' },
    { key: KEYS.core.billing.subscription.manage, name: 'Manage Subscription', description: 'Can manage subscription plan', category: 'billing' },
    { key: KEYS.core.billing.features.manage, name: 'Manage Features', description: 'Can manage feature overrides', category: 'billing' },
    { key: KEYS.core.billing.usage.view, name: 'View Usage', description: 'Can view usage metrics', category: 'billing' },
    { key: KEYS.core.billing.usage.consume, name: 'Consume Usage', description: 'Can consume usage for features', category: 'billing' },
    { key: KEYS.core.billing.entitlements.view, name: 'View Entitlements', description: 'Can view feature entitlements', category: 'billing' },
    { key: KEYS.core.billing.credits.view, name: 'View Credits', description: 'Can view credit balances', category: 'billing' },
    { key: KEYS.core.billing.rebilling.manage, name: 'Manage Rebilling', description: 'Can manage rebilling settings', category: 'billing' },
    { key: KEYS.core.billing.priority_support.view, name: 'View Priority Support', description: 'Can access priority support', category: 'billing' },

    // ========== CORE: SubAccount ==========
    { key: KEYS.core.subaccount.account.read, name: 'View SubAccount', description: 'Can view subaccount account', category: 'subaccount' },
    { key: KEYS.core.subaccount.account.update, name: 'Update SubAccount', description: 'Can update subaccount details', category: 'subaccount' },
    { key: KEYS.core.subaccount.account.delete, name: 'Delete SubAccount', description: 'Can delete the subaccount', category: 'subaccount' },
    { key: KEYS.core.subaccount.team_member.invite, name: 'Invite SubAccount Members', description: 'Can invite subaccount team members', category: 'subaccount' },
    { key: KEYS.core.subaccount.team_member.remove, name: 'Remove SubAccount Members', description: 'Can remove subaccount team members', category: 'subaccount' },

    // ========== CORE: Features ==========
    { key: KEYS.core.experimental.flag.toggle, name: 'Toggle Features', description: 'Can toggle user feature preferences', category: 'features' },

    // ========== CORE: Apps ==========
    { key: KEYS.core.apps.app.view, name: 'View Apps', description: 'Can view installed apps', category: 'apps' },
    { key: KEYS.core.apps.app.install, name: 'Install Apps', description: 'Can install apps', category: 'apps' },
    { key: KEYS.core.apps.app.manage, name: 'Manage Apps', description: 'Can manage app settings', category: 'apps' },
    { key: KEYS.core.apps.app.uninstall, name: 'Uninstall Apps', description: 'Can uninstall apps', category: 'apps' },
    { key: KEYS.core.apps.webhooks.view, name: 'View Webhooks', description: 'Can view webhooks', category: 'apps' },
    { key: KEYS.core.apps.webhooks.manage, name: 'Manage Webhooks', description: 'Can manage webhooks', category: 'apps' },
    { key: KEYS.core.apps.api_keys.read, name: 'View API Keys', description: 'Can view API keys', category: 'apps' },
    { key: KEYS.core.apps.api_keys.create, name: 'Create API Keys', description: 'Can create new API keys', category: 'apps' },
    { key: KEYS.core.apps.api_keys.delete, name: 'Delete API Keys', description: 'Can delete API keys', category: 'apps' },

    { key: KEYS.core.support.diagnostics.run, name: 'Run Diagnostics', description: 'Can run support diagnostics', category: 'support' },
    { key: KEYS.core.support.tickets.view, name: 'View Logs', description: 'Can view support logs', category: 'support' },
    { key: KEYS.core.support.tickets.create, name: 'Manage Tickets', description: 'Can manage support tickets', category: 'support' },
    { key: KEYS.core.support.tickets.update, name: 'Update Tickets', description: 'Can update support tickets', category: 'support' },
    { key: KEYS.core.support.tickets.close, name: 'Close Tickets', description: 'Can close support tickets', category: 'support' },

    // ========== CRM: Customers ==========
    { key: KEYS.crm.customers.contact.read, name: 'View Contacts', description: 'Can view contact information', category: 'contact' },
    { key: KEYS.crm.customers.contact.create, name: 'Create Contacts', description: 'Can create new contacts', category: 'contact' },
    { key: KEYS.crm.customers.contact.update, name: 'Edit Contacts', description: 'Can edit contact details', category: 'contact' },
    { key: KEYS.crm.customers.contact.delete, name: 'Delete Contacts', description: 'Can delete contacts', category: 'contact' },
    { key: KEYS.crm.customers.billing.read, name: 'View Customer Billing', description: 'Can view customer billing', category: 'contact' },
    { key: KEYS.crm.customers.billing.create, name: 'Create Customer Billing', description: 'Can create customer billing', category: 'contact' },
    { key: KEYS.crm.customers.billing.update, name: 'Edit Customer Billing', description: 'Can edit customer billing', category: 'contact' },
    { key: KEYS.crm.customers.billing.delete, name: 'Delete Customer Billing', description: 'Can delete customer billing', category: 'contact' },

    // ========== CRM: Media ==========
    { key: KEYS.crm.media.file.read, name: 'View Media', description: 'Can view media files', category: 'media' },
    { key: KEYS.crm.media.file.create, name: 'Upload Media', description: 'Can upload media files', category: 'media' },
    { key: KEYS.crm.media.file.delete, name: 'Delete Media', description: 'Can delete media files', category: 'media' },

    // ========== CRM: Funnels ==========
    { key: KEYS.crm.funnels.content.read, name: 'View Funnels', description: 'Can view funnels', category: 'funnel' },
    { key: KEYS.crm.funnels.content.create, name: 'Create Funnels', description: 'Can create new funnels', category: 'funnel' },
    { key: KEYS.crm.funnels.content.update, name: 'Edit Funnels', description: 'Can edit funnel content', category: 'funnel' },
    { key: KEYS.crm.funnels.content.delete, name: 'Delete Funnels', description: 'Can delete funnels', category: 'funnel' },
    { key: KEYS.crm.funnels.content.publish, name: 'Publish Funnels', description: 'Can publish funnels', category: 'funnel' },

    // ========== CRM: Pipelines ==========
    { key: KEYS.crm.pipelines.lane.read, name: 'View Pipelines', description: 'Can view pipelines', category: 'pipeline' },
    { key: KEYS.crm.pipelines.lane.create, name: 'Create Pipelines', description: 'Can create new pipelines', category: 'pipeline' },
    { key: KEYS.crm.pipelines.lane.update, name: 'Edit Pipelines', description: 'Can modify pipeline stages', category: 'pipeline' },
    { key: KEYS.crm.pipelines.lane.delete, name: 'Delete Pipelines', description: 'Can delete pipelines', category: 'pipeline' },
    { key: KEYS.crm.pipelines.ticket.read, name: 'View Tickets', description: 'Can view support tickets', category: 'pipeline' },
    { key: KEYS.crm.pipelines.ticket.create, name: 'Create Tickets', description: 'Can create support tickets', category: 'pipeline' },
    { key: KEYS.crm.pipelines.ticket.update, name: 'Edit Tickets', description: 'Can modify support tickets', category: 'pipeline' },
    { key: KEYS.crm.pipelines.ticket.delete, name: 'Delete Tickets', description: 'Can delete support tickets', category: 'pipeline' },
    { key: KEYS.crm.pipelines.tag.read, name: 'View Tags', description: 'Can view tags', category: 'tag' },
    { key: KEYS.crm.pipelines.tag.create, name: 'Create Tags', description: 'Can create new tags', category: 'tag' },
    { key: KEYS.crm.pipelines.tag.update, name: 'Edit Tags', description: 'Can modify tags', category: 'tag' },
    { key: KEYS.crm.pipelines.tag.delete, name: 'Delete Tags', description: 'Can delete tags', category: 'tag' },

    // ========== FI: Configuration ==========
    { key: KEYS.fi.master_data.accounts.view, name: 'View COA Config', description: 'Can view chart of accounts configuration', category: 'fi.configuration' },
    { key: KEYS.fi.master_data.accounts.manage, name: 'Manage COA Config', description: 'Can manage COA structure settings', category: 'fi.configuration' },
    { key: KEYS.fi.configuration.fiscal_years.view, name: 'View Fiscal Years', description: 'Can view fiscal years and periods', category: 'fi.configuration' },
    { key: KEYS.fi.configuration.fiscal_years.manage, name: 'Manage Fiscal Years', description: 'Can open/close fiscal periods', category: 'fi.configuration' },
    { key: KEYS.fi.configuration.currencies.view, name: 'View Currencies', description: 'Can view currencies and exchange rates', category: 'fi.configuration' },
    { key: KEYS.fi.configuration.currencies.manage, name: 'Manage Currencies', description: 'Can manage exchange rates', category: 'fi.configuration' },
    { key: KEYS.fi.configuration.tax_settings.view, name: 'View Tax Settings', description: 'Can view tax configuration', category: 'fi.configuration' },
    { key: KEYS.fi.configuration.tax_settings.manage, name: 'Manage Tax Settings', description: 'Can manage tax codes', category: 'fi.configuration' },
    { key: KEYS.fi.configuration.tolerances.view, name: 'View Tolerances', description: 'Can view tolerance settings', category: 'fi.configuration' },
    { key: KEYS.fi.configuration.tolerances.manage, name: 'Manage Tolerances', description: 'Can manage tolerance limits', category: 'fi.configuration' },
    { key: KEYS.fi.configuration.number_ranges.view, name: 'View Number Ranges', description: 'Can view document number ranges', category: 'fi.configuration' },
    { key: KEYS.fi.configuration.number_ranges.manage, name: 'Manage Number Ranges', description: 'Can manage document numbering', category: 'fi.configuration' },
    { key: KEYS.fi.configuration.posting_rules.view, name: 'View Posting Rules', description: 'Can view posting rules', category: 'fi.configuration' },
    { key: KEYS.fi.configuration.posting_rules.manage, name: 'Manage Posting Rules', description: 'Can manage posting rules', category: 'fi.configuration' },

    // ========== FI: Master Data ==========
    { key: KEYS.fi.master_data.accounts.view, name: 'View Accounts', description: 'Can view chart of accounts', category: 'fi.master_data' },
    { key: KEYS.fi.master_data.accounts.manage, name: 'Manage Accounts', description: 'Can create/edit/delete GL accounts', category: 'fi.master_data' },
    { key: KEYS.fi.master_data.customers.view, name: 'View Customers', description: 'Can view customer master data', category: 'fi.master_data' },
    { key: KEYS.fi.master_data.customers.manage, name: 'Manage Customers', description: 'Can manage customer records', category: 'fi.master_data' },
    { key: KEYS.fi.master_data.vendors.view, name: 'View Vendors', description: 'Can view vendor master data', category: 'fi.master_data' },
    { key: KEYS.fi.master_data.vendors.manage, name: 'Manage Vendors', description: 'Can manage vendor records', category: 'fi.master_data' },
    { key: KEYS.fi.master_data.banks.view, name: 'View Banks', description: 'Can view bank master data', category: 'fi.master_data' },
    { key: KEYS.fi.master_data.banks.manage, name: 'Manage Banks', description: 'Can manage bank records', category: 'fi.master_data' },

    // ========== FI: General Ledger - Settings ==========
    { key: KEYS.fi.general_ledger.settings.view, name: 'View GL Settings', description: 'Can view GL configuration', category: 'fi.general_ledger' },
    { key: KEYS.fi.general_ledger.settings.manage, name: 'Manage GL Settings', description: 'Can modify GL configuration', category: 'fi.general_ledger' },
    { key: KEYS.fi.general_ledger.settings.setup, name: 'Setup GL', description: 'Can perform initial GL setup', category: 'fi.general_ledger' },

    // ========== FI: General Ledger - Journal Entries ==========
    { key: KEYS.fi.general_ledger.journal_entries.read, name: 'View Journal Entries', description: 'Can view journal entries', category: 'fi.general_ledger' },
    { key: KEYS.fi.general_ledger.journal_entries.create, name: 'Create Journal Entries', description: 'Can create journal entries', category: 'fi.general_ledger' },
    { key: KEYS.fi.general_ledger.journal_entries.update, name: 'Edit Journal Entries', description: 'Can edit draft journal entries', category: 'fi.general_ledger' },
    { key: KEYS.fi.general_ledger.journal_entries.delete, name: 'Delete Journal Entries', description: 'Can delete journal entries', category: 'fi.general_ledger' },
    { key: KEYS.fi.general_ledger.journal_entries.approve, name: 'Approve Journal Entries', description: 'Can approve journal entries', category: 'fi.general_ledger' },

    // ========== FI: General Ledger - Reports ==========
    { key: KEYS.fi.general_ledger.reports.view, name: 'View Reports', description: 'Can view financial reports', category: 'fi.general_ledger' },
    { key: KEYS.fi.general_ledger.reports.generate, name: 'Generate Reports', description: 'Can generate financial reports', category: 'fi.general_ledger' },
    { key: KEYS.fi.general_ledger.reports.approve, name: 'Approve Reports', description: 'Can approve financial reports', category: 'fi.general_ledger' },

    // ========== FI: General Ledger - Consolidation ==========
    { key: KEYS.fi.general_ledger.consolidation.view, name: 'View Consolidation', description: 'Can view consolidation data', category: 'fi.general_ledger' },
    { key: KEYS.fi.general_ledger.consolidation.manage, name: 'Manage Consolidation', description: 'Can run consolidation', category: 'fi.general_ledger' },

    // ========== FI: General Ledger - Year End ==========
    { key: KEYS.fi.general_ledger.year_end.view, name: 'View Year End', description: 'Can view year-end status', category: 'fi.general_ledger' },
    { key: KEYS.fi.general_ledger.year_end.manage, name: 'Manage Year End', description: 'Can run year-end closing', category: 'fi.general_ledger' },
    { key: KEYS.fi.general_ledger.year_end.close, name: 'Execute Year End Close', description: 'Can execute year-end closing', category: 'fi.general_ledger' },

    // ========== FI: General Ledger - Reconciliation ==========
    { key: KEYS.fi.general_ledger.reconciliation.view, name: 'View Reconciliation', description: 'Can view reconciliation records', category: 'fi.general_ledger' },
    { key: KEYS.fi.general_ledger.reconciliation.manage, name: 'Manage Reconciliation', description: 'Can manage reconciliations', category: 'fi.general_ledger' },
    { key: KEYS.fi.general_ledger.reconciliation.clear, name: 'Clear Open Items', description: 'Can clear open items', category: 'fi.general_ledger' },

    // ========== FI: Accounts Receivable ==========
    { key: KEYS.fi.accounts_receivable.subledgers.view, name: 'View AR Subledgers', description: 'Can view AR subledgers', category: 'fi.accounts_receivable' },
    { key: KEYS.fi.accounts_receivable.subledgers.allocate, name: 'Allocate AR', description: 'Can allocate AR entries', category: 'fi.accounts_receivable' },
    { key: KEYS.fi.accounts_receivable.subledgers.manage, name: 'Manage AR', description: 'Can manage AR subledgers', category: 'fi.accounts_receivable' },

    // ========== FI: Accounts Payable ==========
    { key: KEYS.fi.accounts_payable.subledgers.view, name: 'View AP Subledgers', description: 'Can view AP subledgers', category: 'fi.accounts_payable' },
    { key: KEYS.fi.accounts_payable.subledgers.allocate, name: 'Allocate AP', description: 'Can allocate AP entries', category: 'fi.accounts_payable' },
    { key: KEYS.fi.accounts_payable.subledgers.manage, name: 'Manage AP', description: 'Can manage AP subledgers', category: 'fi.accounts_payable' },

    // ========== FI: Bank Ledger ==========
    { key: KEYS.fi.bank_ledger.bank_accounts.view, name: 'View Bank Accounts', description: 'Can view bank accounts', category: 'fi.bank_ledger' },
    { key: KEYS.fi.bank_ledger.bank_accounts.manage, name: 'Manage Bank Accounts', description: 'Can manage bank accounts', category: 'fi.bank_ledger' },
    { key: KEYS.fi.bank_ledger.subledgers.view, name: 'View Bank Subledgers', description: 'Can view bank subledgers', category: 'fi.bank_ledger' },
    { key: KEYS.fi.bank_ledger.subledgers.allocate, name: 'Allocate Bank', description: 'Can allocate bank entries', category: 'fi.bank_ledger' },
    { key: KEYS.fi.bank_ledger.subledgers.manage, name: 'Manage Bank Subledgers', description: 'Can manage bank subledgers', category: 'fi.bank_ledger' },

    // ========== FI: Controlling ==========
    { key: KEYS.fi.controlling.cost_centers.view, name: 'View Cost Centers', description: 'Can view cost centers', category: 'fi.controlling' },
    { key: KEYS.fi.controlling.cost_centers.manage, name: 'Manage Cost Centers', description: 'Can manage cost centers', category: 'fi.controlling' },

    // ========== FI: Advanced Reporting ==========
    { key: KEYS.fi.advanced_reporting.financial_statements.view, name: 'View Financial Statements', description: 'Can view financial statements', category: 'fi.advanced_reporting' },
    { key: KEYS.fi.advanced_reporting.financial_statements.generate, name: 'Generate Financial Statements', description: 'Can generate financial statements', category: 'fi.advanced_reporting' },
    { key: KEYS.fi.advanced_reporting.custom_reports.view, name: 'View Custom Reports', description: 'Can view custom reports', category: 'fi.advanced_reporting' },
    { key: KEYS.fi.advanced_reporting.custom_reports.create, name: 'Create Custom Reports', description: 'Can create custom reports', category: 'fi.advanced_reporting' },
    { key: KEYS.fi.advanced_reporting.custom_reports.update, name: 'Edit Custom Reports', description: 'Can edit custom reports', category: 'fi.advanced_reporting' },
    { key: KEYS.fi.advanced_reporting.custom_reports.delete, name: 'Delete Custom Reports', description: 'Can delete custom reports', category: 'fi.advanced_reporting' },
]

// =============================================================================
// DERIVED PERMISSIONS (SSOT) — prevent drift
// =============================================================================

const collectActionKeys = (obj: any, out: string[] = []): string[] => {
    if (!obj) return out
    if (typeof obj === 'string') {
        out.push(obj)
        return out
    }
    if (typeof obj !== 'object') return out
    for (const v of Object.values(obj as Record<string, any>)) {
        collectActionKeys(v, out)
    }
    return out
}

function titleCase(s: string) {
    return s
        .replace(/[_-]+/g, ' ')
        .replace(/\b\w/g, (c) => c.toUpperCase())
}

function defaultPermissionMeta(key: ActionKey): Omit<PermissionDefinition, 'key'> {
    // key pattern: module.domain.resource.action
    const parts = key.split('.')
    const action = parts.at(-1) ?? key
    const resource = parts.at(-2) ?? ''
    const domain = parts.at(-3) ?? ''
    const module = parts.at(-4) ?? parts[0] ?? 'general'
    const category = `${module}.${domain || 'core'}`
    const name = `${titleCase(action)} ${titleCase(resource || domain || 'Resource')}`
    const description = `Allows ${action} on ${resource || domain || 'resource'}`
    return { name, description, category }
}

const ALL_PERMISSION_KEYS = Array.from(new Set(collectActionKeys(KEYS))) as ActionKey[]
const ALL_PERMISSION_SET = new Set<ActionKey>(ALL_PERMISSION_KEYS)

// Filter out stale manual definitions and generate missing ones.
// Manual definitions keep your nicer labels; generator fills the rest.
const MANUAL_DEF_MAP = new Map<ActionKey, PermissionDefinition>()
for (const d of PERMISSION_DEFINITIONS) {
    if (ALL_PERMISSION_SET.has(d.key)) MANUAL_DEF_MAP.set(d.key, d)
}

export const EFFECTIVE_PERMISSION_DEFINITIONS: PermissionDefinition[] = ALL_PERMISSION_KEYS
    .map((k) => MANUAL_DEF_MAP.get(k) ?? ({ key: k, ...defaultPermissionMeta(k) } as PermissionDefinition))
    // stable order for diffs
    .sort((a, b) => a.key.localeCompare(b.key))



// =============================================================================
// ROLE DEFINITIONS
// =============================================================================

type RoleDefinition = {
    name: string
    scope: 'AGENCY' | 'SUBACCOUNT'
    permissions: ActionKey[]
}

const ROLE_DEFINITIONS: RoleDefinition[] = [
    {
        name: 'AGENCY_OWNER',
        scope: 'AGENCY',
        permissions: EFFECTIVE_PERMISSION_DEFINITIONS.map(p => p.key), // All permissions
    },
    {
        name: 'AGENCY_ADMIN',
        scope: 'AGENCY',
        permissions: [
            // Core agency
            KEYS.core.agency.account.read,
            KEYS.core.agency.account.update,
            KEYS.core.agency.settings.view,
            KEYS.core.agency.settings.manage,
            KEYS.core.agency.team_member.invite,
            KEYS.core.agency.team_member.remove,
            KEYS.core.agency.storage.view,
            // Billing (read-only + usage)
            KEYS.core.billing.subscription.view,
            KEYS.core.billing.payment_methods.read,
            KEYS.core.billing.usage.view,
            KEYS.core.billing.usage.consume,
            KEYS.core.billing.entitlements.view,
            KEYS.core.billing.credits.view,
            KEYS.core.experimental.flag.toggle,
            // SubAccounts
            KEYS.core.agency.subaccounts.create,
            KEYS.core.agency.subaccounts.read,
            KEYS.core.agency.subaccounts.update,
            KEYS.core.subaccount.account.read,
            KEYS.core.subaccount.account.update,
            KEYS.core.subaccount.team_member.invite,
            // Support 
            KEYS.core.support.diagnostics.run,
            KEYS.core.support.tickets.view,
            KEYS.core.support.tickets.create,
            KEYS.core.support.tickets.update,
            KEYS.core.support.tickets.close,
            // CRM
            KEYS.crm.funnels.content.create,
            KEYS.crm.funnels.content.read,
            KEYS.crm.funnels.content.update,
            KEYS.crm.funnels.content.publish,
            KEYS.crm.customers.contact.create,
            KEYS.crm.customers.contact.read,
            KEYS.crm.customers.contact.update,
            KEYS.crm.pipelines.lane.create,
            KEYS.crm.pipelines.lane.read,
            KEYS.crm.pipelines.lane.update,
            KEYS.crm.pipelines.ticket.create,
            KEYS.crm.pipelines.ticket.read,
            KEYS.crm.pipelines.ticket.update,
            KEYS.crm.pipelines.tag.create,
            KEYS.crm.pipelines.tag.read,
            KEYS.crm.pipelines.tag.update,
            KEYS.crm.media.file.read,
            KEYS.crm.media.file.create,
            // FI (basic access)
            KEYS.fi.general_ledger.settings.view,
            KEYS.fi.master_data.accounts.view,
            KEYS.fi.general_ledger.journal_entries.read,
            KEYS.fi.configuration.fiscal_years.view,
            KEYS.fi.general_ledger.reports.view,
        ],
    },
    {
        name: 'AGENCY_USER',
        scope: 'AGENCY',
        permissions: [
            KEYS.core.agency.account.read,
            KEYS.core.agency.settings.view,
            KEYS.core.subaccount.account.read,
            KEYS.core.billing.usage.view,
            KEYS.core.billing.entitlements.view,
            KEYS.core.billing.credits.view,
            KEYS.core.experimental.flag.toggle,
            KEYS.core.support.tickets.view,
            KEYS.core.support.tickets.create,
            KEYS.core.support.tickets.update,
            KEYS.core.support.tickets.close,
            KEYS.crm.funnels.content.read,
            KEYS.crm.customers.contact.read,
            KEYS.crm.pipelines.lane.read,
            KEYS.crm.pipelines.ticket.read,
            KEYS.crm.pipelines.tag.read,
            KEYS.crm.media.file.read,
        ],
    },
    {
        name: 'SUBACCOUNT_OWNER',
        scope: 'SUBACCOUNT',
        permissions: EFFECTIVE_PERMISSION_DEFINITIONS
            .filter(p =>
                p.key.startsWith('core.subaccount') ||
                p.key.startsWith('core.support') ||
                p.key.startsWith('core.experimental') ||
                p.key.startsWith('core.apps') ||
                p.key.startsWith('crm.')
            )
            .map(p => p.key),
    },
    {
        name: 'SUBACCOUNT_ADMIN',
        scope: 'SUBACCOUNT',
        permissions: [
            KEYS.core.subaccount.account.read,
            KEYS.core.subaccount.account.update,
            KEYS.core.subaccount.team_member.invite,
            KEYS.core.subaccount.team_member.remove,
            KEYS.core.support.tickets.view,
            KEYS.core.support.tickets.create,
            KEYS.core.support.tickets.update,
            KEYS.core.support.tickets.close,
            KEYS.crm.funnels.content.create,
            KEYS.crm.funnels.content.read,
            KEYS.crm.funnels.content.update,
            KEYS.crm.funnels.content.delete,
            KEYS.crm.funnels.content.publish,
            KEYS.crm.customers.contact.create,
            KEYS.crm.customers.contact.read,
            KEYS.crm.customers.contact.update,
            KEYS.crm.customers.contact.delete,
            KEYS.crm.pipelines.lane.create,
            KEYS.crm.pipelines.lane.read,
            KEYS.crm.pipelines.lane.update,
            KEYS.crm.pipelines.lane.delete,
            KEYS.crm.pipelines.ticket.create,
            KEYS.crm.pipelines.ticket.read,
            KEYS.crm.pipelines.ticket.update,
            KEYS.crm.pipelines.ticket.delete,
            KEYS.crm.pipelines.tag.create,
            KEYS.crm.pipelines.tag.read,
            KEYS.crm.pipelines.tag.update,
            KEYS.crm.media.file.read,
            KEYS.crm.media.file.create,
            KEYS.crm.media.file.delete,
        ],
    },
    {
        name: 'SUBACCOUNT_USER',
        scope: 'SUBACCOUNT',
        permissions: [
            KEYS.core.subaccount.account.read,
            KEYS.crm.funnels.content.read,
            KEYS.crm.funnels.content.update,
            KEYS.crm.customers.contact.create,
            KEYS.crm.customers.contact.read,
            KEYS.crm.customers.contact.update,
            KEYS.crm.pipelines.lane.read,
            KEYS.crm.pipelines.lane.update,
            KEYS.crm.pipelines.ticket.read,
            KEYS.crm.pipelines.ticket.update,
            KEYS.crm.media.file.read,
        ],
    },
    {
        name: 'SUBACCOUNT_GUEST',
        scope: 'SUBACCOUNT',
        permissions: [
            KEYS.core.subaccount.account.read,
            KEYS.crm.funnels.content.read,
            KEYS.crm.customers.contact.read,
            KEYS.crm.pipelines.lane.read,
            KEYS.crm.media.file.read,
        ],
    },
]

// =============================================================================
// FI-GL ACCOUNTANT ROLE (Optional - For finance power users)
// =============================================================================

const FI_GL_ACCOUNTANT_ROLE: RoleDefinition = {
    name: 'FI_GL_ACCOUNTANT',
    scope: 'AGENCY',
    permissions: [
        // Full GL access
        KEYS.fi.general_ledger.settings.view,
        KEYS.fi.master_data.accounts.view,
        KEYS.fi.master_data.accounts.manage,
        KEYS.fi.master_data.accounts.manage,
        KEYS.fi.general_ledger.subledgers.view,
        KEYS.fi.general_ledger.subledgers.allocate,
        KEYS.fi.general_ledger.journal_entries.read,
        KEYS.fi.general_ledger.journal_entries.create,
        KEYS.fi.general_ledger.journal_entries.update,
        KEYS.fi.configuration.fiscal_years.view,
        KEYS.fi.general_ledger.reports.view,
        KEYS.fi.general_ledger.reports.generate,
        KEYS.fi.configuration.currencies.view,
        KEYS.fi.configuration.tax_settings.view,
        KEYS.fi.general_ledger.reconciliation.view,
        KEYS.fi.general_ledger.reconciliation.manage,
        // Configuration
        KEYS.fi.general_ledger.settings.view,
        KEYS.fi.configuration.posting_rules.view,
    ],
}

const FI_GL_MANAGER_ROLE: RoleDefinition = {
    name: 'FI_GL_MANAGER',
    scope: 'AGENCY',
    permissions: [
        // All accountant permissions plus approval/management
        ...FI_GL_ACCOUNTANT_ROLE.permissions,
        KEYS.fi.general_ledger.settings.manage,
        KEYS.fi.master_data.accounts.manage,
        KEYS.fi.general_ledger.journal_entries.delete,
        KEYS.fi.general_ledger.journal_entries.approve,
        KEYS.fi.configuration.fiscal_years.manage,
        KEYS.fi.general_ledger.reports.approve,
        KEYS.fi.general_ledger.consolidation.view,
        KEYS.fi.general_ledger.consolidation.manage,
        KEYS.fi.configuration.currencies.manage,
        KEYS.fi.configuration.tax_settings.manage,
        KEYS.fi.general_ledger.year_end.view,
        KEYS.fi.general_ledger.year_end.manage,
        KEYS.fi.general_ledger.reconciliation.clear,
        // Configuration
        KEYS.fi.general_ledger.settings.manage,
        KEYS.fi.configuration.posting_rules.manage,
    ],
}

// Add FI roles to definitions
ROLE_DEFINITIONS.push(FI_GL_ACCOUNTANT_ROLE)
ROLE_DEFINITIONS.push(FI_GL_MANAGER_ROLE)

// =============================================================================
// SEEDING LOGIC
// =============================================================================

async function main() {
    if (isDryRun) {
        console.log('🔍 DRY RUN MODE - No changes will be made\n')
    }

    console.log('🔐 Seeding permissions and roles...\n')

    // Step 1: Seed Permissions
    console.log('📋 Seeding permissions...')
    const permissionMap = new Map<string, Permission>()
    let permCreated = 0
    let permUpdated = 0

    for (const perm of EFFECTIVE_PERMISSION_DEFINITIONS) {
        if (isDryRun) {
            const existing = await db.permission.findUnique({ where: { key: perm.key } })
            if (existing) {
                console.log(`  [DRY RUN] Would update: ${perm.key}`)
                permUpdated++
                permissionMap.set(perm.key, existing)
            } else {
                console.log(`  [DRY RUN] Would create: ${perm.key}`)
                permCreated++
                permissionMap.set(perm.key, { id: `mock-${perm.key}`, ...perm, isSystem: true, createdAt: new Date() } as Permission)
            }
        } else {
            const existing = await db.permission.findUnique({ where: { key: perm.key } })

            const permission = await db.permission.upsert({
                where: { key: perm.key },
                update: {
                    name: perm.name,
                    description: perm.description,
                    category: perm.category,
                },
                create: {
                    key: perm.key,
                    name: perm.name,
                    description: perm.description,
                    category: perm.category,
                    isSystem: true,
                },
            })

            if (existing) {
                permUpdated++
            } else {
                console.log(`  ✨ Created: ${perm.key}`)
                permCreated++
            }
            permissionMap.set(perm.key, permission)
        }
    }

    console.log(`\n  Permissions: ${permCreated} created, ${permUpdated} updated\n`)

    // Step 2: Cleanup old permission keys
    console.log('🧹 Cleaning up legacy permission keys...')

    const legacyKeys = [
        // Old 3-segment keys
        'subaccount.account.read', 'subaccount.account.update', 'subaccount.users.create',
        'funnel.content.create', 'funnel.content.read', 'funnel.content.update', 'funnel.content.delete', 'funnel.content.publish',
        'contact.data.create', 'contact.data.read', 'contact.data.update', 'contact.data.delete',
        'pipeline.data.create', 'pipeline.data.read', 'pipeline.data.update', 'pipeline.data.delete',
        // Old GL keys (finance.gl.* format)
        'finance.gl.coa.view', 'finance.gl.coa.create', 'finance.gl.coa.edit', 'finance.gl.coa.delete',
        'finance.gl.journal.view', 'finance.gl.journal.create', 'finance.gl.journal.post', 'finance.gl.journal.approve',
        'finance.gl.period.view', 'finance.gl.period.create', 'finance.gl.period.close',
        'finance.gl.report.view', 'finance.gl.report.generate', 'finance.gl.report.export',
        'finance.gl.settings.view', 'finance.gl.settings.edit',
        'finance.gl.audit.view', 'finance.gl.audit.search', 'finance.gl.audit.export',
        'finance.gl.currency.view', 'finance.gl.currency.manage_rates', 'finance.gl.currency.revaluate',
        'finance.gl.consolidation.view', 'finance.gl.consolidation.execute', 'finance.gl.consolidation.approve',
        'finance.gl.posting.view', 'finance.gl.posting.create', 'finance.gl.posting.edit', 'finance.gl.posting.delete',
    ]

    if (isDryRun) {
        const oldPerms = await db.permission.findMany({ where: { key: { in: legacyKeys } } })
        if (oldPerms.length > 0) {
            console.log(`  [DRY RUN] Would delete ${oldPerms.length} legacy permission(s)`)
        } else {
            console.log(`  ✓ No legacy permissions found`)
        }
    } else {
        const deleted = await db.permission.deleteMany({ where: { key: { in: legacyKeys } } })
        if (deleted.count > 0) {
            console.log(`  🗑️  Deleted ${deleted.count} legacy permission(s)`)
        } else {
            console.log(`  ✓ No legacy permissions found`)
        }
    }

    // Step 3: Seed Roles
    console.log('\n👥 Seeding system roles...')

    async function syncRolePermissions(roleId: string, permissionKeys: string[], roleName: string): Promise<number> {
        const rolePermissions = permissionKeys
            .map(key => permissionMap.get(key))
            .filter((p): p is Permission => p !== undefined)

        if (isDryRun) {
            console.log(`  [DRY RUN] Would sync ${rolePermissions.length} permissions for ${roleName}`)
            return rolePermissions.length
        }

        // Remove permissions not in list
        await db.rolePermission.deleteMany({
            where: {
                roleId,
                permissionId: { notIn: rolePermissions.map(p => p.id) },
            },
        })

        // Upsert all
        for (const permission of rolePermissions) {
            await db.rolePermission.upsert({
                where: { roleId_permissionId: { roleId, permissionId: permission.id } },
                update: { granted: true },
                create: { roleId, permissionId: permission.id, granted: true },
            })
        }

        return rolePermissions.length
    }

    for (const roleDef of ROLE_DEFINITIONS) {
        if (isDryRun) {
            const existing = await db.role.findUnique({
                where: { agencyId_subAccountId_name: { agencyId: '', subAccountId: '', name: roleDef.name } },
            })
            console.log(`  [DRY RUN] Would ${existing ? 'update' : 'create'}: ${roleDef.name}`)
        } else {
            const existing = await db.role.findUnique({
                where: { agencyId_subAccountId_name: { agencyId: '', subAccountId: '', name: roleDef.name } },
            })

            const role = await db.role.upsert({
                where: { agencyId_subAccountId_name: { agencyId: '', subAccountId: '', name: roleDef.name } },
                update: {},
                create: { name: roleDef.name, scope: roleDef.scope, isSystem: true },
            })

            const permCount = await syncRolePermissions(role.id, roleDef.permissions, roleDef.name)
            console.log(`  ${existing ? '♻️' : '✨'} ${roleDef.name}: ${permCount} permissions`)
        }
    }

    console.log(`\n✅ ${isDryRun ? 'DRY RUN complete' : 'Permissions and roles seeded successfully!'}`)
    if (isDryRun) {
        console.log('💡 Run without --dry-run to apply changes')
    }
}

main()
    .catch((e) => {
        console.error('❌ Seeding failed:', e)
        process.exit(1)
    })
    .finally(async () => {
        await db.$disconnect()
    })

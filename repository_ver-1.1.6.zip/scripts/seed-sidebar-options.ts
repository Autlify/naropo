/**
 * Seed Script: SidebarOption & SidebarOptionLink
 * 
 * Populates the SidebarOption and SidebarOptionLink tables
 * based on the navigation registry configuration.
 * 
 * Usage: bun run scripts/seed-sidebar-options.ts
 */

import { Icon } from '@/generated/prisma/client'
import { db } from '@/lib/db'
import { FeatureKey, ModuleCode, ModuleKey, SubModuleCode } from '@/lib/registry'


// ============================================================================
// Icon Mapping (string -> Icon enum)
// ============================================================================



const ICON_MAP: Record<string, Icon> = {
    'home': Icon.home,
    'layout-dashboard': Icon.dashboard,
    'dashboard': Icon.dashboard,
    'settings': Icon.settings,
    'credit-card': Icon.creditCard,
    'building-2': Icon.building,
    'building': Icon.building,
    'users': Icon.users,
    'sparkles': Icon.sparkles,
    'grid-3x3': Icon.layers,
    'apps': Icon.apps,
    'contact': Icon.contact,
    'layers': Icon.layers,
    'git-branch': Icon.gitBranch,
    'list-tree': Icon.listTree,
    'file-text': Icon.fileText,
    'calendar': Icon.calendar,
    'bar-chart-3': Icon.barChart3,
    'wallet': Icon.wallet,
    'finance': Icon.finance,
    'rocket': Icon.rocket,
    'image': Icon.image,
    'chart': Icon.chart,
    'info': Icon.info,
    'clipboardIcon': Icon.clipboardIcon,
    'payment': Icon.payment,
    'person': Icon.person,
    'shield': Icon.shield,
    'pipelines': Icon.pipelines,
    'database': Icon.database,
    'chip': Icon.chip,
    'flag': Icon.flag,
}

function getIcon(iconStr: string): Icon {
    return ICON_MAP[iconStr] ?? Icon.info
}

// ============================================================================
// Sidebar Option Definitions
// ============================================================================

interface SidebarOptionDef {
    name: string
    link: string
    icon: string
    module?: ModuleCode
    subModule?: SubModuleCode | 'default'
    order?: number
    agency: boolean
    subaccount: boolean
    user: boolean
    links: SidebarLinkDef[]
}

interface SidebarLinkDef {
    name: string
    link: string
    icon?: string
    order?: number
    feature?: FeatureKey
    agency: boolean
    subaccount: boolean
    user: boolean
}

// ============================================================================
// Core Module Options
// ============================================================================

const SIDEBAR_OPTIONS: SidebarOptionDef[] = [
    {
        name: 'Dashboard',
        icon: 'dashboard',
        module: 'core',
        subModule: 'default',
        link: `/`,
        agency: true,
        subaccount: true,
        user: false,
        order: 10,
        links: [],
    },
    {
        name: 'Launchpad',
        icon: 'clipboardIcon',
        link: `/launchpad`,
        module: 'core',
        subModule: 'default',
        agency: true,
        subaccount: true,
        user: false,
        order: 20,
        links: [],
    },
    {
        name: 'Apps',
        icon: 'apps',
        link: `/apps`,
        module: 'core',
        subModule: 'default',
        agency: true,
        subaccount: true,
        user: false,
        order: 30,
        links: [],
    },

    {
        name: 'Billing',
        icon: 'payment',
        link: `/billing`,
        module: 'core',
        subModule: 'billing',
        agency: true,
        subaccount: false,
        user: false,
        order: 40,
        links: [
            {
                name: 'Subscription',
                link: '/billing/subscription',
                icon: 'receipt',
                feature: 'core.billing.account',
                agency: true,
                subaccount: false,
                user: false,
                order: 10,
            },
            {
                name: 'Payment Methods',
                link: '/billing/payment-methods',
                icon: 'payment',
                feature: 'core.billing.account',
                agency: true,
                subaccount: false,
                user: false,
                order: 20,
            },
            {
                name: 'Usage',
                link: '/billing/usage',
                icon: 'chart',
                feature: 'core.billing.account',
                agency: true,
                subaccount: false,
                user: false,
                order: 30,
            },
            {
                name: 'Credits & Discounts',
                link: '/billing/credits',
                icon: 'wallet',
                feature: 'core.billing.account',
                agency: true,
                subaccount: false,
                user: false,
                order: 40,
            },
            {
                name: 'Addons',
                link: '/billing/addons',
                icon: 'file-text',
                feature: 'core.billing.account',
                agency: true,
                subaccount: false,
                user: false,
                order: 50,
            },
        ],
    },
    {
        name: 'Settings',
        icon: 'settings',
        link: `/settings`,
        module: 'core',
        subModule: 'default',
        agency: true,
        subaccount: true,
        user: false,
        order: 50,
        links: [],
    },
    {
        name: 'Sub-Accounts',
        icon: 'person',
        link: `/all-subaccounts`,
        module: 'core',
        subModule: 'subaccount',
        agency: true,
        subaccount: false,
        user: false,
        order: 60,
        links: [],
    },
    {
        name: 'Team',
        icon: 'shield',
        link: `/team`,
        module: 'iam',
        subModule: 'authZ',
        agency: true,
        subaccount: true,
        user: false,
        order: 70,
        links: [
            {
                name: 'Roles Assignments',
                link: '/team/assignments',
                icon: 'shield',
                feature: 'iam.authZ.members',
                agency: true,
                subaccount: true,
                user: false,
                order: 10,
            },
            {
                name: 'Roles Management',
                link: '/team/roles',
                icon: 'shield',
                feature: 'iam.authZ.roles',
                agency: true,
                subaccount: true,
                user: false,
                order: 20,
            },
        ],
    },
    {
        name: 'Funnels',
        icon: 'pipelines',
        link: `/funnels`,
        module: 'crm',
        subModule: 'funnels',
        agency: false,
        subaccount: true,
        user: false,
        order: 80,
        links: [],
    },
    {
        name: 'Media',
        icon: 'database',
        link: `/media`,
        module: 'core',
        subModule: 'default',
        agency: false,
        subaccount: true,
        user: false,
        order: 90,
        links: [],
    },
    {
        name: 'Automations',
        icon: 'chip',
        link: `/automations`,
        module: 'core',
        subModule: 'organization',
        agency: false,
        subaccount: true,
        user: false,
        order: 100,
        links: [],
    },
    {
        name: 'Pipelines',
        icon: 'flag',
        link: `/pipelines`,
        module: 'crm',
        subModule: 'pipelines',
        agency: false,
        subaccount: true,
        user: false,
        order: 110,
        links: [],
    },
    {
        name: 'Contacts',
        icon: 'person',
        link: `/contacts`,
        module: 'crm',
        subModule: 'customers',
        agency: false,
        subaccount: true,
        user: false,
        order: 120,
        links: [],
    },
    {
        name: 'General Ledger',
        link: '/fi/general-ledger',
        icon: 'finance',
        module: 'fi',
        subModule: 'general_ledger',
        agency: true,
        subaccount: true,
        user: false,
        order: 130,
        links: [
            {
                name: 'Overview',
                link: '/fi/general-ledger',
                icon: 'dashboard',
                feature: 'fi.general_ledger.accounts',
                agency: true,
                subaccount: true,
                user: false,
                order: 10,
            },
            {
                name: 'Chart of Accounts',
                link: '/fi/general-ledger/chart-of-accounts',
                icon: 'list-tree',
                feature: 'fi.master_data.accounts',
                agency: true,
                subaccount: true,
                user: false,
                order: 20,
            },
            {
                name: 'Journal Entries',
                link: '/fi/general-ledger/journal-entries',
                icon: 'file-text',
                feature: 'fi.general_ledger.journal_entries',
                agency: true,
                subaccount: true,
                user: false,
                order: 30,
            },
            {
                name: 'Approvals',
                link: '/fi/general-ledger/approvals',
                icon: 'clipboardIcon',
                feature: 'fi.general_ledger.journal_entries',
                agency: true,
                subaccount: true,
                user: false,
                order: 40,
            },
            {
                name: 'Financial Periods',
                link: '/fi/general-ledger/periods',
                icon: 'calendar',
                feature: 'fi.configuration.fiscal_years',
                agency: true,
                subaccount: true,
                user: false,
                order: 50,
            },
            {
                name: 'Reports',
                link: '/fi/general-ledger/reports',
                icon: 'bar-chart-3',
                feature: 'fi.general_ledger.reports',
                agency: true,
                subaccount: true,
                user: false,
                order: 60,
            },
            {
                name: 'Audit Trail',
                link: '/fi/general-ledger/audit',
                icon: 'shield',
                feature: 'fi.general_ledger.settings',
                agency: true,
                subaccount: false,
                user: false,
                order: 70,
            },
            {
                name: 'Consolidation',
                link: '/fi/general-ledger/consolidation',
                icon: 'chart',
                feature: 'fi.general_ledger.consolidation',
                agency: true,
                subaccount: false,
                user: false,
                order: 80,
            },
            {
                name: 'Settings',
                link: '/fi/general-ledger/settings',
                icon: 'settings',
                feature: 'fi.general_ledger.settings',
                agency: true,
                subaccount: true,
                user: false,
                order: 90,
            },
        ],
    },
    {
        name: 'Banking',
        link: '/fi/banking',
        icon: 'wallet',
        module: 'fi',
        subModule: 'bank_ledger',
        agency: true,
        subaccount: true,
        user: false,
        order: 140,
        links: [
            {
                name: 'Transactions',
                link: '/fi/bank-ledger/subledgers',
                icon: 'wallet',
                feature: 'fi.bank_ledger.subledgers',
                agency: true,
                subaccount: true,
                user: false,
                order: 10,
            },
            {
                name: 'Reconciliation',
                link: '/fi/bank-ledger/bank-accounts',
                icon: 'shield',
                feature: 'fi.bank_ledger.bank_accounts',
                agency: true,
                subaccount: true,
                user: false,
                order: 20,
            },
        ],
    },
]


// ============================================================================
// Seed Function
// ============================================================================

async function seedSidebarOptions() {
    console.log('🌱 Seeding SidebarOption & SidebarOptionLink...')

    // Combine all options
    const allOptions: SidebarOptionDef[] = [
        ...SIDEBAR_OPTIONS,
    ]

    // Clear existing data
    console.log('🧹 Clearing existing sidebar options...')
    await db.sidebarOptionLink.deleteMany()
    await db.sidebarOption.deleteMany()

    // Create sidebar options with links
    for (const optionDef of allOptions) {
        console.log(`  📁 Creating: ${optionDef.name}`)

        const sidebarOption = await db.sidebarOption.create({
            data: {
                name: optionDef.name,
                link: optionDef.link,
                icon: getIcon(optionDef.icon),
                module: optionDef.module,
                subModule: optionDef.subModule,
                agency: optionDef.agency,
                subaccount: optionDef.subaccount,
                user: optionDef.user,
            },
        })

        // Create links for this option
        for (const linkDef of optionDef.links) {
            await db.sidebarOptionLink.create({
                data: {
                    name: linkDef.name,
                    link: linkDef.link,
                    icon: linkDef.icon ? getIcon(linkDef.icon) : null,
                    feature: linkDef.feature,
                    agency: linkDef.agency,
                    subaccount: linkDef.subaccount,
                    user: linkDef.user,
                    sidebarOptionId: sidebarOption.id,
                },
            })
        }
    }

    // Summary
    const optionCount = await db.sidebarOption.count()
    const linkCount = await db.sidebarOptionLink.count()

    console.log('')
    console.log('✅ Seeding complete!')
    console.log(`   SidebarOption: ${optionCount} records`)
    console.log(`   SidebarOptionLink: ${linkCount} records`)
}

// ============================================================================
// Main
// ============================================================================

async function main() {
    try {
        await seedSidebarOptions()
    } catch (error) {
        console.error('❌ Seed failed:', error)
        process.exit(1)
    } finally {
        await db.$disconnect()
    }
}

main()
